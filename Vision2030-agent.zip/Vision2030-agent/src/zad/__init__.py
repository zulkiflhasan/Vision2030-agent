"""Zad — an AI agent that reduces food waste in Hajj and Umrah mass catering.

Aligned with Saudi Vision 2030 and UN SDG target 12.3. See ``README.md``.
"""

__version__ = "0.1.0"
