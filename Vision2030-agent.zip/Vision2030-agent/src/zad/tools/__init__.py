"""Domain tools the agent can call. See :mod:`zad.tools.registry` for the catalogue."""
