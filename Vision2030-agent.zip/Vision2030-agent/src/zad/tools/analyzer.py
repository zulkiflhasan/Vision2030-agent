"""Tool 2 — descriptive waste analysis.

Two measures are reported for every group:

* **Over-preparation rate** — meals prepared but not served, as a share of meals
  prepared. This is the surplus that better planning can remove or redistribute.
* **Plate waste** — grams of food left on plates per served meal. This cannot be
  redistributed; it can only be reduced at source or composted.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from pydantic import Field

from zad.models import GroupBy, MealServiceRecord, StrictModel, WasteAnalysis, WasteGroup
from zad.tools.context import ToolContext
from zad.tools.data_loader import ensure_loaded

HOTSPOT_MARGIN_PCT = 2.0
MAX_HOTSPOTS = 3


class AnalyzeWasteInput(StrictModel):
    """Arguments for ``analyze_waste``."""

    group_by: GroupBy = Field(
        default="camp",
        description="Dimension to break the waste metrics down by.",
    )


def _group_key(record: MealServiceRecord, group_by: GroupBy) -> str:
    if group_by == "camp":
        return record.camp_id
    if group_by == "site":
        return record.site
    if group_by == "meal_type":
        return record.meal_type
    return record.service_date.isoformat()


def summarise(key: str, records: Iterable[MealServiceRecord]) -> WasteGroup:
    """Aggregate waste metrics over ``records`` under the label ``key``."""
    prepared = served = 0
    plate_waste = 0.0
    for record in records:
        prepared += record.meals_prepared
        served += record.meals_served
        plate_waste += record.plate_waste_kg
    unserved = prepared - served
    return WasteGroup(
        key=key,
        meals_prepared=prepared,
        meals_served=served,
        unserved_meals=unserved,
        overprep_rate_pct=round(100 * unserved / prepared, 2) if prepared else 0.0,
        plate_waste_kg=round(plate_waste, 1),
        plate_waste_g_per_served_meal=round(1000 * plate_waste / served, 1) if served else 0.0,
    )


def analyze_waste(ctx: ToolContext, args: AnalyzeWasteInput) -> WasteAnalysis:
    """Compute waste metrics overall and per group, and flag the worst groups.

    A group is a hotspot when its over-preparation rate is more than
    ``HOTSPOT_MARGIN_PCT`` percentage points above the overall rate. If no group
    clears that margin, the single highest group is reported so that the result
    always names where to look first.
    """
    ensure_loaded(ctx)
    buckets: dict[str, list[MealServiceRecord]] = defaultdict(list)
    for record in ctx.records:
        buckets[_group_key(record, args.group_by)].append(record)

    overall = summarise("overall", ctx.records)
    groups = sorted(
        (summarise(key, members) for key, members in buckets.items()),
        key=lambda group: (-group.overprep_rate_pct, group.key),
    )
    threshold = overall.overprep_rate_pct + HOTSPOT_MARGIN_PCT
    hotspots = [group.key for group in groups if group.overprep_rate_pct > threshold]
    ctx.waste = WasteAnalysis(
        group_by=args.group_by,
        overall=overall,
        groups=groups,
        hotspots=hotspots[:MAX_HOTSPOTS] or [groups[0].key],
    )
    return ctx.waste
