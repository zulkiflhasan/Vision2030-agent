"""Shared state for one agent run.

Tools are plain functions that read from and write to a :class:`ToolContext`.
Later tools build on the results of earlier ones (the recommender needs the
forecast, the report needs everything), so the context caches each result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from zad.models import (
    AgentReport,
    Charity,
    DatasetSummary,
    DemandForecast,
    Language,
    MealServiceRecord,
    OccupancyPlan,
    PolicyContext,
    Recommendation,
    RedistributionPlan,
    ToolCallRecord,
    WasteAnalysis,
)


class ToolError(Exception):
    """Raised by a tool when it cannot produce a result.

    The message is returned to the model as an error ``tool_result`` so that it
    can correct its call, and is shown to the user if the run cannot continue.
    """


@dataclass
class ToolContext:
    """Mutable state shared by all tool calls in a single agent run."""

    data_dir: Path
    question: str = ""
    language: Language = "en"
    mode: str = "mock"
    plan: list[str] = field(default_factory=list)
    records: list[MealServiceRecord] = field(default_factory=list)
    plans: list[OccupancyPlan] = field(default_factory=list)
    charities: list[Charity] = field(default_factory=list)
    dataset: DatasetSummary | None = None
    waste: WasteAnalysis | None = None
    forecast: DemandForecast | None = None
    redistribution: RedistributionPlan | None = None
    recommendations: list[Recommendation] = field(default_factory=list)
    policy: PolicyContext | None = None
    report: AgentReport | None = None
    trace: list[ToolCallRecord] = field(default_factory=list)
