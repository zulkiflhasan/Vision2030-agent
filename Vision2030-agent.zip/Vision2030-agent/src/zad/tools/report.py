"""Tool 7 — assemble the structured report and render it as Markdown.

The report is built from the cached tool results, so every number in it comes
from a tool. The language model contributes only the executive summary text.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Literal

from pydantic import Field

from zad.i18n import LABELS, LIMITATIONS, confidence_label, counted
from zad.models import AgentReport, Language, StrictModel
from zad.tools.analyzer import AnalyzeWasteInput, analyze_waste
from zad.tools.context import ToolContext
from zad.tools.data_loader import ensure_loaded
from zad.tools.forecaster import ensure_forecast
from zad.tools.policy import ensure_policy
from zad.tools.recommender import RecommendActionsInput, recommend_actions
from zad.tools.redistribution import ensure_redistribution


class GenerateReportInput(StrictModel):
    """Arguments for ``generate_report``."""

    executive_summary: str = Field(
        min_length=20,
        description=(
            "Two to five sentences for decision-makers, in the report language, based only "
            "on figures returned by the other tools."
        ),
    )
    language: Language | None = Field(
        default=None,
        description="Report language: 'en' or 'ar'. Defaults to the question's language.",
    )


def generate_report(ctx: ToolContext, args: GenerateReportInput) -> AgentReport:
    """Build the final :class:`AgentReport`, running any analysis step still missing."""
    language: Language = args.language or ctx.language
    dataset = ensure_loaded(ctx)
    waste = ctx.waste or analyze_waste(ctx, AnalyzeWasteInput(group_by="camp"))
    forecast = ensure_forecast(ctx)
    redistribution = ensure_redistribution(ctx)
    # Recommendations are always rebuilt here so that their language matches the report.
    recommendations = recommend_actions(ctx, RecommendActionsInput(language=language))
    mode: Literal["mock", "live"] = "live" if ctx.mode == "live" else "mock"
    ctx.report = AgentReport(
        title=LABELS[language]["title"],
        language=language,
        mode=mode,
        question=ctx.question,
        plan=list(ctx.plan),
        executive_summary=args.executive_summary.strip(),
        dataset=dataset,
        waste=waste,
        forecast=forecast,
        redistribution=redistribution,
        recommendations=recommendations,
        context=ensure_policy(ctx),
        limitations=LIMITATIONS[language],
        trace=list(ctx.trace),
    )
    return ctx.report


def _table(header: list[str], rows: list[list[str]]) -> list[str]:
    lines = ["| " + " | ".join(header) + " |", "|" + "|".join(" --- " for _ in header) + "|"]
    lines.extend("| " + " | ".join(row) + " |" for row in rows)
    return lines


def render_markdown(report: AgentReport) -> str:
    """Render ``report`` as a Markdown document in the report's language."""
    text = LABELS[report.language]
    dataset, waste, forecast, plan = (
        report.dataset,
        report.waste,
        report.forecast,
        report.redistribution,
    )
    arabic = report.language == "ar"
    provenance = (dataset.provenance_ar if arabic else None) or dataset.provenance
    lines: list[str] = [f"# {report.title}", ""]
    lines += [
        f"**{text['question']}:** {report.question}",
        f"**{text['mode']}:** {text['mode_' + report.mode]}",
        f"**{text['data']}:** {provenance}",
        "",
        f"## {text['summary']}",
        "",
        report.executive_summary,
        "",
        f"## {text['kpis']}",
        "",
    ]
    hotspot_rates = {group.key: group.overprep_rate_pct for group in waste.groups}
    hotspots = ", ".join(
        f"{key} ({hotspot_rates[key]}%)" if key in hotspot_rates else key for key in waste.hotspots
    )
    lines += _table(
        [text["metric"], text["value"]],
        [
            [
                text["period"],
                f"{dataset.first_date} → {dataset.last_date} "
                f"({counted(dataset.days, 'day', report.language)})",
            ],
            [text["records"], f"{dataset.records:,}"],
            [text["prepared"], f"{dataset.total_meals_prepared:,}"],
            [text["served"], f"{dataset.total_meals_served:,}"],
            [text["overprep"], f"{waste.overall.overprep_rate_pct}%"],
            [
                text["plate_waste"],
                f"{dataset.total_plate_waste_kg:,} {text['kg']} "
                f"({waste.overall.plate_waste_g_per_served_meal} {text['g']} {text['per_meal']})",
            ],
            [text["hotspots"], hotspots],
        ],
    )

    lines += ["", f"## {text['forecast']} {forecast.target_date}", ""]
    backtest_span = counted(forecast.backtest_days, "day", report.language)
    per_camp: dict[str, list[int]] = defaultdict(lambda: [0, 0, 0, 0])
    for item in forecast.items:
        totals = per_camp[item.camp_id]
        totals[0] += item.forecast_meals
        totals[1] += item.recommended_prep
        totals[2] += item.habitual_prep
        totals[3] += item.meals_avoided
    rows = [
        [camp, *(f"{value:,}" for value in totals)] for camp, totals in sorted(per_camp.items())
    ]
    rows.append(
        [
            f"**{text['total']}**",
            f"**{forecast.total_forecast_meals:,}**",
            f"**{forecast.total_recommended_prep:,}**",
            f"**{forecast.total_habitual_prep:,}**",
            f"**{forecast.total_meals_avoided:,}**",
        ]
    )
    lines += _table(
        [
            text["camp"],
            text["forecast_meals"],
            text["recommended"],
            text["habitual"],
            text["avoided"],
        ],
        rows,
    )
    lines += [
        "",
        f"{text['service_level']}: {forecast.service_level:.0%} · {text['backtest']}: "
        f"{forecast.backtest_mape_pct}% ({backtest_span}) · "
        f"{text['confidence']}: {confidence_label(forecast.confidence, report.language)}",
        "",
        f"## {text['redistribution']}",
        "",
    ]
    lines += _table(
        [text["camp"], text["charity"], text["meals"], text["distance"], text["cold_chain"]],
        [
            [
                allocation.camp_id,
                allocation.charity_name,
                f"{allocation.meals:,}",
                f"{allocation.distance_km:g}",
                text["yes"] if allocation.cold_chain else text["no"],
            ]
            for allocation in plan.allocations
        ],
    )
    lines += [
        "",
        f"{text['placed']}: {plan.allocated_meals:,} / {plan.surplus_meals:,} "
        f"({plan.placement_rate_pct}%) · {text['unplaced']}: {plan.unallocated_meals:,}",
        "",
        f"> {text['inspector']}",
        "",
        f"## {text['recommendations']}",
        "",
    ]
    for item in report.recommendations:
        lines += [
            f"### {item.rec_id}. {item.title}",
            "",
            f"- **{text['action']}:** {item.action}",
            f"- **{text['impact']}:** {item.expected_impact}",
            f"- **{text['vision']}:** {item.vision2030_objective}",
            f"- **{text['sdg']}:** `SDG {item.sdg_target}` ({text['indicator']} "
            f"{item.sdg_indicator})",
            f"- **{text['confidence']}:** {item.confidence_note}",
            f"- **{text['approval']}:** "
            f"{text['yes'] if item.requires_human_approval else text['no']}",
            "",
        ]

    lines += [f"## {text['context']}", ""]
    for fact in report.context.facts:
        statement = fact.statement_ar if arabic else fact.statement_en
        lines.append(f"- {statement} ({text['source']}: [{fact.source_name}]({fact.source_url}))")

    if report.plan:
        lines += ["", f"## {text['plan']}", ""]
        lines += [f"{number}. {step}" for number, step in enumerate(report.plan, start=1)]

    if report.trace:
        lines += ["", f"## {text['trace']}", ""]
        lines += [
            f"{record.step}. `{record.tool}` — {'ok' if record.ok else 'error'}: {record.summary}"
            for record in report.trace
        ]

    lines += ["", f"## {text['limitations']}", ""]
    lines += [f"- {limitation}" for limitation in report.limitations]
    return "\n".join(lines) + "\n"
