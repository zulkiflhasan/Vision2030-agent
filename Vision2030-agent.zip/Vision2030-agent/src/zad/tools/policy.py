"""Tool 6 — published national figures with their sources.

The facts are read from ``zad/reference/national_context.json``. Each one was
checked against the cited source; see ``docs/PROBLEM_SELECTION.md``. The agent
quotes these figures instead of relying on the language model's memory.
"""

from __future__ import annotations

import json
from importlib import resources

from pydantic import ValidationError

from zad.models import PolicyContext, StrictModel
from zad.tools.context import ToolContext, ToolError

REFERENCE_PACKAGE = "zad.reference"
REFERENCE_FILE = "national_context.json"


class GetPolicyContextInput(StrictModel):
    """``get_policy_context`` takes no arguments."""


def get_policy_context(ctx: ToolContext, args: GetPolicyContextInput) -> PolicyContext:
    """Return the verified national facts bundled with the package."""
    del args  # the tool has no arguments; the parameter keeps the tool signature uniform
    raw = resources.files(REFERENCE_PACKAGE).joinpath(REFERENCE_FILE).read_text(encoding="utf-8")
    try:
        ctx.policy = PolicyContext.model_validate({"facts": json.loads(raw)["facts"]})
    except (json.JSONDecodeError, KeyError, ValidationError) as exc:
        raise ToolError(f"{REFERENCE_FILE} is malformed: {exc}") from exc
    return ctx.policy


def ensure_policy(ctx: ToolContext) -> PolicyContext:
    """Return the cached policy context, loading it if needed."""
    if ctx.policy is None:
        return get_policy_context(ctx, GetPolicyContextInput())
    return ctx.policy
