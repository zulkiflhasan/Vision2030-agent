"""Tool 5 — turn the analysis into tagged, confidence-rated recommendations.

Recommendations are built from fixed bilingual templates filled with numbers
computed by the other tools. The language model never writes the SDG tag, the
numbers or the confidence note; it can only choose to call this tool.
"""

from __future__ import annotations

from pydantic import Field

from zad.i18n import VISION_OBJECTIVES, confidence_label, counted
from zad.models import Confidence, Language, Recommendation, StrictModel
from zad.tools.analyzer import AnalyzeWasteInput, analyze_waste
from zad.tools.context import ToolContext
from zad.tools.data_loader import ensure_loaded
from zad.tools.forecaster import ensure_forecast
from zad.tools.redistribution import ensure_redistribution

MIN_DAYS_FOR_HIGH = 10
DOWNGRADE: dict[Confidence, Confidence] = {"high": "medium", "medium": "low", "low": "low"}


class RecommendActionsInput(StrictModel):
    """Arguments for ``recommend_actions``."""

    language: Language | None = Field(
        default=None,
        description="Language of the recommendations: 'en' or 'ar'. Defaults to the question's.",
    )
    max_items: int = Field(default=5, ge=1, le=5, description="Maximum number to return.")


def _pct(part: float, whole: float) -> float:
    return round(100 * part / whole, 1) if whole else 0.0


def recommend_actions(ctx: ToolContext, args: RecommendActionsInput) -> list[Recommendation]:
    """Build the recommendation list from the cached analysis, forecast and plan."""
    language: Language = args.language or ctx.language
    dataset = ensure_loaded(ctx)
    if ctx.waste is None or ctx.waste.group_by != "camp":
        by_camp = analyze_waste(ctx, AnalyzeWasteInput(group_by="camp"))
    else:
        by_camp = ctx.waste
    forecast = ensure_forecast(ctx)
    plan = ensure_redistribution(ctx)
    arabic = language == "ar"
    day = forecast.target_date.isoformat()
    forecast_label = confidence_label(forecast.confidence, language)
    synthetic = "synthetic" in dataset.provenance.casefold()
    data_note = (
        (
            " البيانات تجريبية مُولَّدة وليست قياسات حقيقية."
            if arabic
            else " The input is synthetic sample data, not field measurements."
        )
        if synthetic
        else ""
    )
    recommendations: list[Recommendation] = []

    # 1. Preparation sizing -------------------------------------------------------
    avoided_pct = _pct(forecast.total_meals_avoided, forecast.total_habitual_prep)
    recommendations.append(
        Recommendation(
            rec_id="R1",
            title="ضبط كميات الإعداد وفق التنبؤ" if arabic else "Size preparation to the forecast",
            action=(
                f"إعداد {forecast.total_recommended_prep:,} وجبة ليوم {day} بدلًا من "
                f"{forecast.total_habitual_prep:,} وجبة حسب المعتاد، وفق جدول المخيمات المرفق."
                if arabic
                else f"Prepare {forecast.total_recommended_prep:,} meals for {day} instead of "
                f"the habitual {forecast.total_habitual_prep:,}, following the per-camp table."
            ),
            expected_impact=(
                f"تجنّب إعداد نحو {forecast.total_meals_avoided:,} وجبة ({avoided_pct}%) مع "
                f"تغطية الطلب بمستوى خدمة {forecast.service_level:.0%}."
                if arabic
                else f"About {forecast.total_meals_avoided:,} meals ({avoided_pct}%) not "
                f"over-prepared, while covering demand at a {forecast.service_level:.0%} "
                "service level."
            ),
            vision2030_objective=VISION_OBJECTIVES["pep_quality"][language],
            sdg_target="12.3",
            sdg_indicator="12.3.1(b)",
            confidence=forecast.confidence,
            confidence_note=(
                f"ثقة {forecast_label}: متوسط خطأ الاختبار الرجعي {forecast.backtest_mape_pct}% "
                f"على آخر {counted(forecast.backtest_days, 'day', language)}.{data_note}"
                if arabic
                else f"{forecast_label.capitalize()} confidence: back-test error (MAPE) of "
                f"{forecast.backtest_mape_pct}% over the last "
                f"{counted(forecast.backtest_days, 'day', language)}."
                f"{data_note}"
            ),
        )
    )

    # 2. Hotspot review -----------------------------------------------------------
    hotspot_confidence: Confidence = "high" if dataset.days >= MIN_DAYS_FOR_HIGH else "medium"
    hotspot_rates = {group.key: group.overprep_rate_pct for group in by_camp.groups}
    hotspot_text = ", ".join(f"{key} ({hotspot_rates[key]}%)" for key in by_camp.hotspots)
    recommendations.append(
        Recommendation(
            rec_id="R2",
            title="مراجعة المخيمات الأعلى في الإعداد الزائد"
            if arabic
            else "Review the over-preparation hotspots",
            action=(
                f"مراجعة طلبات الإعاشة مع مشرفي المخيمات: {hotspot_text}، مقابل متوسط عام "
                f"{by_camp.overall.overprep_rate_pct}%."
                if arabic
                else f"Review catering orders with the supervisors of: {hotspot_text}, against "
                f"an overall rate of {by_camp.overall.overprep_rate_pct}%."
            ),
            expected_impact=(
                "تقريب نسبة الإعداد الزائد في هذه المخيمات من المتوسط العام."
                if arabic
                else "Bring these camps' over-preparation rate towards the overall average."
            ),
            vision2030_objective=VISION_OBJECTIVES["ntp_food"][language],
            sdg_target="12.3",
            sdg_indicator="12.3.1(b)",
            confidence=hotspot_confidence,
            confidence_note=(
                f"ثقة {confidence_label(hotspot_confidence, language)}: إحصاء وصفي مباشر من "
                f"{counted(dataset.records, 'record', language)} على مدى "
                f"{counted(dataset.days, 'day', language)} دون نموذج تنبؤي."
                f"{data_note}"
                if arabic
                else f"{confidence_label(hotspot_confidence, language).capitalize()} confidence: "
                "a direct descriptive statistic over "
                f"{counted(dataset.records, 'record', language)} and "
                f"{counted(dataset.days, 'day', language)}, with no predictive model "
                f"involved.{data_note}"
            ),
        )
    )

    # 3. Redistribution -----------------------------------------------------------
    plan_confidence = DOWNGRADE[forecast.confidence]
    charities_used = len({allocation.charity_id for allocation in plan.allocations})
    recommendations.append(
        Recommendation(
            rec_id="R3",
            title="إعادة توزيع الفائض الصالح على الجمعيات"
            if arabic
            else "Redistribute safe surplus to charities",
            action=(
                f"تنسيق استلام {plan.allocated_meals:,} وجبة فائضة متوقعة يوم {day} عبر "
                f"{counted(charities_used, 'charity', language)} وفق خطة التوزيع، بعد موافقة مراقب "
                "سلامة الغذاء."
                if arabic
                else f"Arrange collection of {plan.allocated_meals:,} expected surplus meals on "
                f"{day} by {counted(charities_used, 'charity', language)} as per the allocation "
                "plan, subject to "
                "food-safety inspector approval."
            ),
            expected_impact=(
                f"توجيه {plan.placement_rate_pct}% من الفائض المتوقع إلى المستفيدين بدلًا من "
                "التخلص منه."
                if arabic
                else f"{plan.placement_rate_pct}% of expected surplus reaches people in need "
                "instead of being discarded."
            ),
            vision2030_objective=VISION_OBJECTIVES["ntp_food"][language],
            sdg_target="2.1",
            sdg_indicator="2.1.2",
            confidence=plan_confidence,
            confidence_note=(
                f"ثقة {confidence_label(plan_confidence, language)}: الخطة مبنية على فائض متوقَّع "
                "لا فعلي وعلى طاقة استيعابية مُصرَّح بها من الجمعيات، وصلاحية الوجبات يقرّرها "
                f"المراقب.{data_note}"
                if arabic
                else f"{confidence_label(plan_confidence, language).capitalize()} confidence: the "
                "plan rests on forecast (not actual) surplus and on capacity declared by the "
                f"charities; edibility is decided by the inspector.{data_note}"
            ),
        )
    )

    # 4. Composting of plate waste ------------------------------------------------
    daily_plate_waste = round(dataset.total_plate_waste_kg / dataset.days, 1)
    recommendations.append(
        Recommendation(
            rec_id="R4",
            title="تحويل هدر الأطباق إلى التسميد" if arabic else "Send plate waste to composting",
            action=(
                f"فرز هدر الأطباق (نحو {daily_plate_waste:,} كجم يوميًّا) في حاويات مستقلة "
                "وتوجيهه إلى التسميد بدلًا من المردم."
                if arabic
                else f"Separate plate waste (about {daily_plate_waste:,} kg per day) at source "
                "and route it to composting instead of landfill."
            ),
            expected_impact=(
                f"تحويل ما يصل إلى {dataset.total_plate_waste_kg:,} كجم خلال فترة مماثلة "
                f"({counted(dataset.days, 'day', language)}) عن مسار النفايات البلدية."
                if arabic
                else f"Up to {dataset.total_plate_waste_kg:,} kg diverted from municipal waste "
                f"over a comparable {dataset.days}-day period."
            ),
            vision2030_objective=VISION_OBJECTIVES["ntp_pollution"][language],
            sdg_target="12.5",
            sdg_indicator="12.5.1",
            confidence="medium",
            confidence_note=(
                f"ثقة {confidence_label('medium', language)}: الكميات موزونة في السجلات، لكن "
                f"طاقة التسميد المتاحة غير مدرجة في البيانات.{data_note}"
                if arabic
                else f"{confidence_label('medium', language).capitalize()} confidence: quantities "
                "are weighed in the records, but available composting capacity is not in the "
                f"data.{data_note}"
            ),
        )
    )

    # 5. Unplaced surplus (only when the plan leaves some) --------------------------
    if plan.unallocated_meals > 0:
        recommendations.append(
            Recommendation(
                rec_id="R5",
                title="تأمين طاقة استلام إضافية للفائض غير الموزَّع"
                if arabic
                else "Secure extra collection capacity for unplaced surplus",
                action=(
                    f"التعاقد مسبقًا على طاقة استلام إضافية لنحو {plan.unallocated_meals:,} "
                    f"وجبة لم تجد جهة مستلمة يوم {day}."
                    if arabic
                    else f"Pre-arrange additional charity capacity for about "
                    f"{plan.unallocated_meals:,} meals that have no taker on {day}."
                ),
                expected_impact=(
                    "منع دخول هذه الوجبات إلى مسار النفايات البلدية في المشاعر المقدسة."
                    if arabic
                    else "Keeps these meals out of the municipal waste stream of the holy sites."
                ),
                vision2030_objective=VISION_OBJECTIVES["ntp_pollution"][language],
                sdg_target="11.6",
                sdg_indicator="11.6.1",
                confidence=plan_confidence,
                confidence_note=(
                    f"ثقة {confidence_label(plan_confidence, language)}: الرقم هو الفرق بين فائض "
                    f"متوقَّع وطاقة مُصرَّح بها، وكلاهما تقديري.{data_note}"
                    if arabic
                    else f"{confidence_label(plan_confidence, language).capitalize()} confidence: "
                    "the figure is the gap between forecast surplus and declared capacity, both "
                    f"of which are estimates.{data_note}"
                ),
            )
        )

    ctx.recommendations = recommendations[: args.max_items]
    return ctx.recommendations
