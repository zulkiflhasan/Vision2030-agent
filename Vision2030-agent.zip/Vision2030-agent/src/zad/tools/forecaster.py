"""Tool 3 — meal-demand forecast and preparation sizing.

Method (deliberately simple and auditable):

1. For each camp and meal, compute the daily *attendance ratio*
   ``meals_served / registered_pilgrims``.
2. Forecast the next ratio as an exponentially weighted mean of past ratios
   (recent days weigh more), and multiply by the planned headcount.
3. Size preparation as ``forecast + z * sigma``, where ``sigma`` is the standard
   deviation of the ratio scaled to meals and ``z`` is the normal quantile for the
   requested service level. Preparation is never below the forecast plus a small
   floor buffer, so the rule cannot recommend under-serving pilgrims.
4. Back-test on the most recent days to report an honest error figure.
"""

from __future__ import annotations

import math
from collections import defaultdict
from datetime import date
from statistics import NormalDist, fmean, pstdev

from pydantic import Field

from zad.models import (
    Confidence,
    DemandForecast,
    ForecastItem,
    MealServiceRecord,
    MealType,
    StrictModel,
)
from zad.tools.context import ToolContext, ToolError
from zad.tools.data_loader import ensure_loaded

EW_ALPHA = 0.5
FALLBACK_SIGMA = 0.05
FLOOR_BUFFER = 0.02
BACKTEST_DAYS = 3
MIN_HISTORY_FOR_HIGH = 7
MAPE_HIGH_PCT = 5.0
MAPE_MEDIUM_PCT = 10.0
METHOD = (
    "Exponentially weighted mean of the attendance ratio (alpha=0.5) times planned "
    "headcount; preparation = forecast + z*sigma with a 2% floor buffer."
)

SeriesKey = tuple[str, MealType]


class ForecastDemandInput(StrictModel):
    """Arguments for ``forecast_demand``."""

    target_date: date | None = Field(
        default=None,
        description="Service date to forecast (ISO format). Defaults to the first planned date.",
    )
    service_level: float = Field(
        default=0.95,
        ge=0.5,
        le=0.999,
        description="Probability that preparation covers demand, between 0.5 and 0.999.",
    )


def ew_mean(values: list[float], alpha: float = EW_ALPHA) -> float:
    """Exponentially weighted mean; the last value has the highest weight."""
    if not values:
        raise ValueError("ew_mean needs at least one value")
    weights = [(1 - alpha) ** (len(values) - 1 - index) for index in range(len(values))]
    return sum(weight * value for weight, value in zip(weights, values, strict=True)) / sum(weights)


def ratio_sigma(ratios: list[float]) -> float:
    """Standard deviation of the attendance ratio, with a fallback for short history."""
    return pstdev(ratios) if len(ratios) >= 2 else FALLBACK_SIGMA


def size_preparation(forecast: float, sigma_meals: float, service_level: float) -> int:
    """Return the number of meals to prepare for ``forecast`` expected meals."""
    z_score = NormalDist().inv_cdf(service_level)
    with_buffer = forecast + z_score * sigma_meals
    return math.ceil(max(with_buffer, forecast * (1 + FLOOR_BUFFER)))


def _series(records: list[MealServiceRecord]) -> dict[SeriesKey, list[MealServiceRecord]]:
    grouped: dict[SeriesKey, list[MealServiceRecord]] = defaultdict(list)
    for record in sorted(records, key=lambda item: item.service_date):
        grouped[(record.camp_id, record.meal_type)].append(record)
    return grouped


def _backtest(series: dict[SeriesKey, list[MealServiceRecord]]) -> tuple[int, float]:
    """Walk forward over the last days of history; return (days used, MAPE in percent)."""
    all_dates = sorted({record.service_date for members in series.values() for record in members})
    test_dates = all_dates[-BACKTEST_DAYS:] if len(all_dates) > BACKTEST_DAYS else all_dates[1:]
    errors: list[float] = []
    for test_date in test_dates:
        for members in series.values():
            past = [record for record in members if record.service_date < test_date]
            actual = next((r for r in members if r.service_date == test_date), None)
            if actual is None or not past or actual.meals_served == 0:
                continue
            ratios = [record.meals_served / record.registered_pilgrims for record in past]
            predicted = ew_mean(ratios) * actual.registered_pilgrims
            errors.append(abs(predicted - actual.meals_served) / actual.meals_served)
    if not errors:
        raise ToolError("Not enough history to back-test the forecast (need at least 2 days).")
    return len(test_dates), round(100 * fmean(errors), 2)


def confidence_from(mape_pct: float, min_history_days: int) -> Confidence:
    """Map back-test error and history length to a confidence label."""
    if mape_pct < MAPE_HIGH_PCT and min_history_days >= MIN_HISTORY_FOR_HIGH:
        return "high"
    if mape_pct < MAPE_MEDIUM_PCT:
        return "medium"
    return "low"


def forecast_demand(ctx: ToolContext, args: ForecastDemandInput) -> DemandForecast:
    """Forecast meals per camp and meal for the target date and size preparation."""
    ensure_loaded(ctx)
    planned_dates = sorted({plan.service_date for plan in ctx.plans})
    if not planned_dates:
        raise ToolError("occupancy_plan.csv has no planned dates for the loaded camps.")
    target = args.target_date or planned_dates[0]
    headcount = {
        plan.camp_id: plan.registered_pilgrims for plan in ctx.plans if plan.service_date == target
    }
    if not headcount:
        available = ", ".join(day.isoformat() for day in planned_dates)
        raise ToolError(f"No occupancy plan for {target.isoformat()}. Planned dates: {available}.")

    series = _series([record for record in ctx.records if record.service_date < target])
    items: list[ForecastItem] = []
    for (camp_id, meal_type), members in sorted(series.items()):
        if camp_id not in headcount:
            continue
        registered = headcount[camp_id]
        ratios = [record.meals_served / record.registered_pilgrims for record in members]
        prep_ratios = [record.meals_prepared / record.registered_pilgrims for record in members]
        expected = ew_mean(ratios) * registered
        sigma_meals = ratio_sigma(ratios) * registered
        z_score = NormalDist().inv_cdf(args.service_level)
        forecast_meals = round(expected)
        recommended = size_preparation(expected, sigma_meals, args.service_level)
        habitual = round(fmean(prep_ratios) * registered)
        items.append(
            ForecastItem(
                camp_id=camp_id,
                meal_type=meal_type,
                registered_pilgrims=registered,
                forecast_meals=forecast_meals,
                lower_meals=max(math.floor(expected - z_score * sigma_meals), 0),
                upper_meals=math.ceil(expected + z_score * sigma_meals),
                recommended_prep=recommended,
                habitual_prep=habitual,
                meals_avoided=max(habitual - recommended, 0),
                expected_surplus=recommended - forecast_meals,
                history_days=len(members),
            )
        )
    if not items:
        raise ToolError(f"No history before {target.isoformat()} for the planned camps.")

    backtest_days, mape_pct = _backtest(series)
    ctx.forecast = DemandForecast(
        target_date=target,
        service_level=args.service_level,
        method=METHOD,
        items=items,
        total_forecast_meals=sum(item.forecast_meals for item in items),
        total_recommended_prep=sum(item.recommended_prep for item in items),
        total_habitual_prep=sum(item.habitual_prep for item in items),
        total_meals_avoided=sum(item.meals_avoided for item in items),
        total_expected_surplus=sum(item.expected_surplus for item in items),
        backtest_days=backtest_days,
        backtest_mape_pct=mape_pct,
        confidence=confidence_from(mape_pct, min(item.history_days for item in items)),
    )
    return ctx.forecast


def ensure_forecast(ctx: ToolContext) -> DemandForecast:
    """Return the cached forecast, computing it with defaults if needed."""
    if ctx.forecast is None:
        return forecast_demand(ctx, ForecastDemandInput())
    return ctx.forecast
