"""Tool 4 — surplus redistribution plan.

Allocates each camp's expected surplus (preparation minus forecast) to charities.
The rule is greedy and transparent: the camp with the largest surplus is served
first, by the nearest eligible charity with remaining capacity. Charities farther
than ``COLD_CHAIN_KM`` are eligible only if they have refrigerated transport.

The plan is a proposal. Whether any meal is safe to hand over is decided by a
food-safety inspector, never by this tool.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date

from pydantic import Field

from zad.models import Allocation, RedistributionPlan, StrictModel
from zad.tools.context import ToolContext, ToolError
from zad.tools.forecaster import ForecastDemandInput, ensure_forecast, forecast_demand

COLD_CHAIN_KM = 15.0
RULE = (
    "Greedy: largest camp surplus first, nearest charity with free capacity first; "
    f"charities beyond {COLD_CHAIN_KM:g} km must have cold-chain transport."
)


class PlanRedistributionInput(StrictModel):
    """Arguments for ``plan_redistribution``."""

    target_date: date | None = Field(
        default=None,
        description="Service date to plan for (ISO format). Defaults to the forecast date.",
    )


def plan_redistribution(ctx: ToolContext, args: PlanRedistributionInput) -> RedistributionPlan:
    """Assign expected surplus meals to charities for the target date."""
    forecast = ensure_forecast(ctx)
    if args.target_date is not None and args.target_date != forecast.target_date:
        forecast = forecast_demand(
            ctx,
            ForecastDemandInput(target_date=args.target_date, service_level=forecast.service_level),
        )
    if not ctx.charities:
        raise ToolError("charities.csv has no charities to allocate surplus to.")

    surplus_by_camp: dict[str, int] = defaultdict(int)
    for item in forecast.items:
        surplus_by_camp[item.camp_id] += item.expected_surplus

    eligible = sorted(
        (
            charity
            for charity in ctx.charities
            if charity.distance_km <= COLD_CHAIN_KM or charity.has_cold_chain
        ),
        key=lambda charity: (charity.distance_km, charity.charity_id),
    )
    remaining = {charity.charity_id: charity.daily_capacity_meals for charity in eligible}

    allocations: list[Allocation] = []
    for camp_id, surplus in sorted(surplus_by_camp.items(), key=lambda pair: (-pair[1], pair[0])):
        left = surplus
        for charity in eligible:
            if left == 0:
                break
            meals = min(left, remaining[charity.charity_id])
            if meals == 0:
                continue
            remaining[charity.charity_id] -= meals
            left -= meals
            allocations.append(
                Allocation(
                    camp_id=camp_id,
                    charity_id=charity.charity_id,
                    charity_name=charity.name,
                    meals=meals,
                    distance_km=charity.distance_km,
                    cold_chain=charity.has_cold_chain,
                )
            )

    total_surplus = sum(surplus_by_camp.values())
    allocated = sum(allocation.meals for allocation in allocations)
    ctx.redistribution = RedistributionPlan(
        target_date=forecast.target_date,
        surplus_meals=total_surplus,
        allocated_meals=allocated,
        unallocated_meals=total_surplus - allocated,
        placement_rate_pct=round(100 * allocated / total_surplus, 1) if total_surplus else 0.0,
        allocations=allocations,
        rule=RULE,
    )
    return ctx.redistribution


def ensure_redistribution(ctx: ToolContext) -> RedistributionPlan:
    """Return the cached plan, computing it with defaults if needed."""
    if ctx.redistribution is None:
        return plan_redistribution(ctx, PlanRedistributionInput())
    return ctx.redistribution
