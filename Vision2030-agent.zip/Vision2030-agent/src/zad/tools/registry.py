"""Tool registry: schemas for the model and safe execution for the agent loop."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, ValidationError

from zad.models import (
    AgentReport,
    DatasetSummary,
    DemandForecast,
    PolicyContext,
    Recommendation,
    RedistributionPlan,
    ToolCallRecord,
    WasteAnalysis,
)
from zad.tools.analyzer import AnalyzeWasteInput, analyze_waste
from zad.tools.context import ToolContext, ToolError
from zad.tools.data_loader import LoadServiceDataInput, load_service_data
from zad.tools.forecaster import ForecastDemandInput, forecast_demand
from zad.tools.policy import GetPolicyContextInput, get_policy_context
from zad.tools.recommender import RecommendActionsInput, recommend_actions
from zad.tools.redistribution import PlanRedistributionInput, plan_redistribution
from zad.tools.report import GenerateReportInput, generate_report


@dataclass(frozen=True)
class ToolSpec:
    """Everything the agent needs to advertise and run one tool."""

    name: str
    description: str
    input_model: type[BaseModel]
    handler: Callable[[ToolContext, Any], Any]
    summarise: Callable[[Any], str]
    to_payload: Callable[[Any], Any]


@dataclass(frozen=True)
class ToolResult:
    """Outcome of one tool execution, ready to send back to the model."""

    ok: bool
    content: str
    summary: str


def _dump(result: Any) -> Any:
    if isinstance(result, BaseModel):
        return result.model_dump(mode="json")
    return [item.model_dump(mode="json") for item in result]


def _report_payload(report: AgentReport) -> dict[str, Any]:
    return {
        "status": "report_ready",
        "language": report.language,
        "recommendations": [
            {"rec_id": item.rec_id, "title": item.title, "sdg_target": item.sdg_target}
            for item in report.recommendations
        ],
    }


def _summarise_dataset(result: DatasetSummary) -> str:
    return f"{result.records} records, {len(result.camps)} camps, {result.days} days"


def _summarise_waste(result: WasteAnalysis) -> str:
    return (
        f"over-preparation {result.overall.overprep_rate_pct}% overall; "
        f"hotspots: {', '.join(result.hotspots)}"
    )


def _summarise_forecast(result: DemandForecast) -> str:
    return (
        f"{result.target_date}: forecast {result.total_forecast_meals:,}, prepare "
        f"{result.total_recommended_prep:,} (habitual {result.total_habitual_prep:,}); "
        f"MAPE {result.backtest_mape_pct}%"
    )


def _summarise_plan(result: RedistributionPlan) -> str:
    return (
        f"{result.allocated_meals:,} of {result.surplus_meals:,} surplus meals placed "
        f"({result.placement_rate_pct}%)"
    )


def _summarise_recommendations(result: list[Recommendation]) -> str:
    return f"{len(result)} recommendations: " + ", ".join(
        f"{item.rec_id}→SDG {item.sdg_target}" for item in result
    )


def _summarise_policy(result: PolicyContext) -> str:
    return f"{len(result.facts)} sourced facts"


def _summarise_report(result: AgentReport) -> str:
    return f"report built in '{result.language}' with {len(result.recommendations)} recommendations"


TOOLS: tuple[ToolSpec, ...] = (
    ToolSpec(
        name="load_service_data",
        description=(
            "Load and validate the meal-service records, the occupancy plan and the list of "
            "charities. Call this first. Returns the period covered, camps, totals and the "
            "data provenance statement."
        ),
        input_model=LoadServiceDataInput,
        handler=load_service_data,
        summarise=_summarise_dataset,
        to_payload=_dump,
    ),
    ToolSpec(
        name="analyze_waste",
        description=(
            "Compute the over-preparation rate and plate waste, overall and broken down by "
            "camp, site, meal type or date, and name the hotspots."
        ),
        input_model=AnalyzeWasteInput,
        handler=analyze_waste,
        summarise=_summarise_waste,
        to_payload=_dump,
    ),
    ToolSpec(
        name="forecast_demand",
        description=(
            "Forecast meals per camp and meal for a planned service date, recommend how many "
            "meals to prepare at a given service level, and report back-test error."
        ),
        input_model=ForecastDemandInput,
        handler=forecast_demand,
        summarise=_summarise_forecast,
        to_payload=_dump,
    ),
    ToolSpec(
        name="plan_redistribution",
        description=(
            "Allocate the expected surplus meals of the forecast date to charities by distance "
            "and capacity. The plan always requires food-safety inspector approval."
        ),
        input_model=PlanRedistributionInput,
        handler=plan_redistribution,
        summarise=_summarise_plan,
        to_payload=_dump,
    ),
    ToolSpec(
        name="recommend_actions",
        description=(
            "Produce the list of recommended actions. Each one carries its SDG target and "
            "indicator, the Vision 2030 objective, a confidence level and a confidence note."
        ),
        input_model=RecommendActionsInput,
        handler=recommend_actions,
        summarise=_summarise_recommendations,
        to_payload=_dump,
    ),
    ToolSpec(
        name="get_policy_context",
        description=(
            "Return published national figures (food loss and waste index, Hajj pilgrim "
            "numbers, SDG 12.3) with source URLs. Use these instead of figures from memory."
        ),
        input_model=GetPolicyContextInput,
        handler=get_policy_context,
        summarise=_summarise_policy,
        to_payload=_dump,
    ),
    ToolSpec(
        name="generate_report",
        description=(
            "Build the final structured report from all previous results. Call this last, "
            "exactly once, with an executive summary written in the report language."
        ),
        input_model=GenerateReportInput,
        handler=generate_report,
        summarise=_summarise_report,
        to_payload=_report_payload,
    ),
)

TOOLS_BY_NAME: dict[str, ToolSpec] = {spec.name: spec for spec in TOOLS}


def anthropic_tool_schemas() -> list[dict[str, Any]]:
    """Return the tool definitions in the format expected by the Anthropic Messages API."""
    return [
        {
            "name": spec.name,
            "description": spec.description,
            "input_schema": spec.input_model.model_json_schema(),
        }
        for spec in TOOLS
    ]


def execute_tool(ctx: ToolContext, name: str, arguments: dict[str, Any]) -> ToolResult:
    """Validate ``arguments``, run the tool and record the call in the context trace.

    Never raises for expected failures (unknown tool, invalid arguments, a
    :class:`ToolError`): those are returned as an error result so the model can
    correct itself.
    """
    spec = TOOLS_BY_NAME.get(name)
    if spec is None:
        known = ", ".join(TOOLS_BY_NAME)
        result = ToolResult(
            False, f"Unknown tool '{name}'. Available tools: {known}.", "unknown tool"
        )
    else:
        try:
            output = spec.handler(ctx, spec.input_model.model_validate(arguments))
        except ValidationError as exc:
            problems = "; ".join(
                f"{'.'.join(str(part) for part in error['loc']) or 'input'}: {error['msg']}"
                for error in exc.errors()
            )
            result = ToolResult(
                False, f"Invalid arguments for {name}: {problems}", "invalid arguments"
            )
        except ToolError as exc:
            result = ToolResult(False, str(exc), str(exc))
        else:
            result = ToolResult(
                True,
                json.dumps(spec.to_payload(output), ensure_ascii=False),
                spec.summarise(output),
            )
    ctx.trace.append(
        ToolCallRecord(
            step=len(ctx.trace) + 1,
            tool=name,
            arguments=arguments,
            ok=result.ok,
            summary=result.summary,
        )
    )
    return result
