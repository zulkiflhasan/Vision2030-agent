"""Tool 1 — load and validate meal-service data.

Reads three CSV files and an optional ``manifest.json`` from the data directory:

* ``meal_service.csv``  — historical meal services (one row per camp, day, meal)
* ``occupancy_plan.csv`` — planned headcount for upcoming service dates
* ``charities.csv``     — charities able to collect surplus meals
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import TypeVar

from pydantic import BaseModel, Field, ValidationError

from zad.models import Charity, DatasetSummary, MealServiceRecord, OccupancyPlan, StrictModel
from zad.tools.context import ToolContext, ToolError

MEAL_SERVICE_FILE = "meal_service.csv"
OCCUPANCY_FILE = "occupancy_plan.csv"
CHARITIES_FILE = "charities.csv"
MANIFEST_FILE = "manifest.json"

ModelT = TypeVar("ModelT", bound=BaseModel)


class LoadServiceDataInput(StrictModel):
    """Arguments for ``load_service_data``."""

    site: str | None = Field(
        default=None,
        description="Optional site name to restrict the analysis to, for example 'Mina'.",
    )


def read_csv_models(path: Path, model: type[ModelT]) -> list[ModelT]:
    """Read ``path`` and validate every row against ``model``.

    Raises:
        ToolError: if the file is missing, empty, or any row fails validation.
            Unknown columns fail validation because the models forbid extra fields.
    """
    if not path.is_file():
        raise ToolError(f"Data file not found: {path}")
    rows: list[ModelT] = []
    with path.open(newline="", encoding="utf-8") as handle:
        for line_number, row in enumerate(csv.DictReader(handle), start=2):
            try:
                rows.append(model.model_validate(row))
            except ValidationError as exc:
                first = exc.errors()[0]
                location = ".".join(str(part) for part in first["loc"]) or "row"
                raise ToolError(
                    f"{path.name} line {line_number}: {location}: {first['msg']}"
                ) from exc
    if not rows:
        raise ToolError(f"Data file has no rows: {path}")
    return rows


def read_provenance(data_dir: Path) -> tuple[str, str | None]:
    """Return the (English, Arabic) provenance statements from ``manifest.json``.

    The Arabic statement is optional; the English one falls back to "unknown".
    """
    manifest = data_dir / MANIFEST_FILE
    if not manifest.is_file():
        return "unknown (no manifest.json in the data directory)", None
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ToolError(f"{MANIFEST_FILE} is not valid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise ToolError(f"{MANIFEST_FILE} must contain a JSON object.")
    english = str(payload.get("provenance", "unknown (manifest.json has no 'provenance' key)"))
    arabic = payload.get("provenance_ar")
    return english, str(arabic) if arabic else None


def load_service_data(ctx: ToolContext, args: LoadServiceDataInput) -> DatasetSummary:
    """Load all input files into the context and return a summary of what was loaded."""
    records = read_csv_models(ctx.data_dir / MEAL_SERVICE_FILE, MealServiceRecord)
    if args.site is not None:
        wanted = args.site.strip().casefold()
        records = [record for record in records if record.site.casefold() == wanted]
        if not records:
            raise ToolError(f"No meal-service records for site '{args.site}'.")
    camps = sorted({record.camp_id for record in records})
    plans = [
        plan
        for plan in read_csv_models(ctx.data_dir / OCCUPANCY_FILE, OccupancyPlan)
        if plan.camp_id in camps
    ]
    charities = read_csv_models(ctx.data_dir / CHARITIES_FILE, Charity)
    dates = sorted({record.service_date for record in records})
    provenance, provenance_ar = read_provenance(ctx.data_dir)

    ctx.records = records
    ctx.plans = plans
    ctx.charities = charities
    ctx.dataset = DatasetSummary(
        records=len(records),
        camps=camps,
        sites=sorted({record.site for record in records}),
        first_date=dates[0],
        last_date=dates[-1],
        days=len(dates),
        total_meals_prepared=sum(record.meals_prepared for record in records),
        total_meals_served=sum(record.meals_served for record in records),
        total_plate_waste_kg=round(sum(record.plate_waste_kg for record in records), 1),
        charities=len(charities),
        planned_dates=sorted({plan.service_date for plan in plans}),
        provenance=provenance,
        provenance_ar=provenance_ar,
    )
    return ctx.dataset


def ensure_loaded(ctx: ToolContext) -> DatasetSummary:
    """Return the dataset summary, loading the data first if no tool has done so."""
    if ctx.dataset is None:
        return load_service_data(ctx, LoadServiceDataInput())
    return ctx.dataset
