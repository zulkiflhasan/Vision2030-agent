"""Prompt templates, stored as Markdown files and loaded with :func:`load_prompt`."""

from __future__ import annotations

from importlib import resources


def load_prompt(name: str) -> str:
    """Return the text of ``prompts/<name>.md``."""
    return resources.files(__name__).joinpath(f"{name}.md").read_text(encoding="utf-8").strip()
