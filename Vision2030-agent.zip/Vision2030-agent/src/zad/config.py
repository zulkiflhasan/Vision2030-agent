"""Runtime configuration, read from environment variables and an optional ``.env`` file."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

DEFAULT_MODEL = "claude-sonnet-5-5"
DEFAULT_MAX_TOKENS = 4096
DEFAULT_MAX_STEPS = 12
SAMPLE_DATA_SUBDIR = Path("data") / "sample"


class ConfigError(Exception):
    """Raised when the configuration is unusable."""


@dataclass(frozen=True)
class Settings:
    """Settings for one agent run."""

    api_key: str | None
    model: str
    max_tokens: int
    max_steps: int
    data_dir: Path


def _positive_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer, got '{raw}'.") from exc
    if value <= 0:
        raise ConfigError(f"{name} must be positive, got {value}.")
    return value


def default_data_dir() -> Path:
    """Locate the sample data: ``./data/sample`` first, then the repository checkout."""
    in_cwd = Path.cwd() / SAMPLE_DATA_SUBDIR
    if in_cwd.is_dir():
        return in_cwd
    return Path(__file__).resolve().parents[2] / SAMPLE_DATA_SUBDIR


def load_settings(data_dir: Path | None = None) -> Settings:
    """Build :class:`Settings` from the environment.

    ``data_dir`` given explicitly wins over ``ZAD_DATA_DIR``, which wins over the
    bundled sample data.
    """
    load_dotenv()
    env_dir = os.getenv("ZAD_DATA_DIR")
    resolved = data_dir or (Path(env_dir) if env_dir else default_data_dir())
    if not resolved.is_dir():
        raise ConfigError(f"Data directory not found: {resolved}")
    return Settings(
        api_key=os.getenv("ANTHROPIC_API_KEY") or None,
        model=os.getenv("ZAD_MODEL") or DEFAULT_MODEL,
        max_tokens=_positive_int("ZAD_MAX_TOKENS", DEFAULT_MAX_TOKENS),
        max_steps=_positive_int("ZAD_MAX_STEPS", DEFAULT_MAX_STEPS),
        data_dir=resolved,
    )
