"""The agent: planner → tool calls → reasoning → structured report.

One run has three stages:

1. **Plan.** A tool-free model call turns the question into a short list of steps.
2. **Act.** A tool-use loop: the model requests tools, the agent executes them and
   returns the results, until the model stops requesting tools.
3. **Report.** The structured :class:`~zad.models.AgentReport` built by the
   ``generate_report`` tool is returned. If the model never called that tool, the
   agent calls it itself so that every run ends with a validated report.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from zad.i18n import detect_language
from zad.llm import LLMClient, LLMError, LLMResponse, Message
from zad.models import AgentReport, Language
from zad.prompts import load_prompt
from zad.tools.context import ToolContext, ToolError
from zad.tools.registry import TOOLS, anthropic_tool_schemas, execute_tool
from zad.tools.report import GenerateReportInput, generate_report

LANGUAGE_NAMES: dict[Language, str] = {"en": "English", "ar": "Arabic"}
MIN_SUMMARY_CHARS = 20
JSON_ARRAY = re.compile(r"\[.*\]", re.DOTALL)


class AgentError(Exception):
    """Raised when a run cannot produce a report."""


@dataclass(frozen=True)
class AgentResult:
    """What a run returns: the structured report plus the model's closing message."""

    report: AgentReport
    final_message: str
    model_calls: int


class Agent:
    """Runs the plan-act-report cycle against any :class:`~zad.llm.LLMClient`."""

    def __init__(
        self, client: LLMClient, *, data_dir: Path, mode: str, max_steps: int = 12
    ) -> None:
        """Create an agent.

        Args:
            client: Language-model client (live or mock).
            data_dir: Directory holding the CSV inputs.
            mode: ``"live"`` or ``"mock"``; recorded in the report.
            max_steps: Maximum number of model calls in the tool-use loop.
        """
        if max_steps < 1:
            raise ValueError("max_steps must be at least 1")
        self._client = client
        self._data_dir = data_dir
        self._mode = mode
        self._max_steps = max_steps

    def run(self, question: str, language: Language | None = None) -> AgentResult:
        """Answer ``question`` and return the structured report.

        Args:
            question: The user's question, in Arabic or English.
            language: Force the reply language; detected from the question if omitted.

        Raises:
            AgentError: if the question is empty, the model fails, the step limit is
                reached, or the data cannot support a report.
        """
        question = question.strip()
        if not question:
            raise AgentError("The question is empty.")
        resolved: Language = language or detect_language(question)
        ctx = ToolContext(
            data_dir=self._data_dir, question=question, language=resolved, mode=self._mode
        )
        try:
            ctx.plan = self._plan(question, resolved)
            final_message, model_calls = self._act(ctx, question, resolved)
            report = ctx.report or self._fallback_report(ctx, final_message)
        except (LLMError, ToolError) as exc:
            raise AgentError(str(exc)) from exc
        report = report.model_copy(update={"trace": list(ctx.trace)})
        return AgentResult(report=report, final_message=final_message, model_calls=model_calls + 1)

    # ------------------------------------------------------------------ stages

    def _plan(self, question: str, language: Language) -> list[str]:
        """Stage 1: ask the model for a step list (no tools offered)."""
        tool_list = "\n".join(f"- {spec.name}: {spec.description}" for spec in TOOLS)
        system = load_prompt("planner").format(
            tool_list=tool_list, language_name=LANGUAGE_NAMES[language]
        )
        reply = self._client.complete(
            system=system, messages=[{"role": "user", "content": question}], tools=[]
        )
        return parse_plan(reply.text)

    def _act(self, ctx: ToolContext, question: str, language: Language) -> tuple[str, int]:
        """Stage 2: the tool-use loop. Returns the closing message and the call count."""
        system = load_prompt("system").format(language_name=LANGUAGE_NAMES[language])
        plan_text = "\n".join(f"{number}. {step}" for number, step in enumerate(ctx.plan, start=1))
        messages: list[Message] = [{"role": "user", "content": f"{question}\n\nPlan:\n{plan_text}"}]
        tools = anthropic_tool_schemas()
        for call_number in range(1, self._max_steps + 1):
            reply = self._client.complete(system=system, messages=messages, tools=tools)
            if not reply.tool_calls:
                return reply.text, call_number
            messages.append(reply.as_message())
            messages.append({"role": "user", "content": self._run_tools(ctx, reply)})
        raise AgentError(
            f"Stopped after {self._max_steps} model calls without a final answer. "
            "Raise ZAD_MAX_STEPS or simplify the question."
        )

    @staticmethod
    def _run_tools(ctx: ToolContext, reply: LLMResponse) -> list[dict[str, Any]]:
        """Execute every tool call in ``reply`` and build the ``tool_result`` blocks."""
        blocks: list[dict[str, Any]] = []
        for call in reply.tool_calls:
            result = execute_tool(ctx, call.name, call.arguments)
            block: dict[str, Any] = {
                "type": "tool_result",
                "tool_use_id": call.call_id,
                "content": result.content,
            }
            if not result.ok:
                block["is_error"] = True
            blocks.append(block)
        return blocks

    @staticmethod
    def _fallback_report(ctx: ToolContext, final_message: str) -> AgentReport:
        """Stage 3 safety net: build the report when the model did not call the tool."""
        if len(final_message.strip()) < MIN_SUMMARY_CHARS:
            raise AgentError(
                "The model ended the run without calling generate_report and without a "
                "usable summary."
            )
        return generate_report(ctx, GenerateReportInput(executive_summary=final_message))


def parse_plan(text: str) -> list[str]:
    """Extract the plan steps from the planner's reply.

    Accepts a JSON array of strings (the requested format) and falls back to one
    step per non-empty line, with list markers stripped, if the reply is not JSON.

    Raises:
        LLMError: if no steps can be extracted.
    """
    match = JSON_ARRAY.search(text)
    if match:
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError:
            parsed = None
        if isinstance(parsed, list):
            steps = [str(step).strip() for step in parsed if str(step).strip()]
            if steps:
                return steps
    steps = [re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).strip() for line in text.splitlines()]
    steps = [step for step in steps if step]
    if not steps:
        raise LLMError("The planner returned an empty plan.")
    return steps
