"""Language-model clients: the live Anthropic client and the offline mock.

Both implement :class:`LLMClient`, so the agent loop is the same code in live and
mock mode. Messages use the Anthropic Messages API wire format throughout.
"""

from __future__ import annotations

import json
from typing import Any, Protocol

import anthropic

from zad.i18n import counted
from zad.models import Language, StrictModel

Message = dict[str, Any]


class LLMError(Exception):
    """Raised when the language model cannot be reached or returns an unusable reply."""


class ToolCall(StrictModel):
    """A tool invocation requested by the model."""

    call_id: str
    name: str
    arguments: dict[str, Any]


class LLMResponse(StrictModel):
    """Provider-neutral view of one model reply."""

    text: str
    tool_calls: list[ToolCall]
    stop_reason: str

    def as_message(self) -> Message:
        """Return this reply as an assistant message in Anthropic wire format."""
        content: list[dict[str, Any]] = []
        if self.text:
            content.append({"type": "text", "text": self.text})
        content.extend(
            {"type": "tool_use", "id": call.call_id, "name": call.name, "input": call.arguments}
            for call in self.tool_calls
        )
        return {"role": "assistant", "content": content}


class LLMClient(Protocol):
    """Minimal interface the agent needs from a language model."""

    def complete(
        self, *, system: str, messages: list[Message], tools: list[dict[str, Any]]
    ) -> LLMResponse:
        """Return the model's next reply for the conversation so far."""
        ...


class AnthropicClient:
    """Live client backed by the Anthropic Messages API."""

    def __init__(
        self,
        *,
        api_key: str | None,
        model: str,
        max_tokens: int,
        sdk_client: anthropic.Anthropic | None = None,
    ) -> None:
        """Create the client.

        Args:
            api_key: Anthropic API key. Required unless ``sdk_client`` is given.
            model: Model identifier, for example ``claude-sonnet-5-5``.
            max_tokens: Upper bound on tokens generated per reply.
            sdk_client: Pre-built SDK client, used by tests to avoid network calls.

        Raises:
            LLMError: if neither an API key nor an SDK client is supplied.
        """
        if sdk_client is None and not api_key:
            raise LLMError(
                "ANTHROPIC_API_KEY is not set. Add it to your environment or .env file, "
                "or run with --mock to use the offline mode."
            )
        self._client = sdk_client or anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    def complete(
        self, *, system: str, messages: list[Message], tools: list[dict[str, Any]]
    ) -> LLMResponse:
        """Call the Messages API and convert the reply to :class:`LLMResponse`."""
        request: dict[str, Any] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "system": system,
            "messages": messages,
        }
        if tools:
            request["tools"] = tools
        try:
            reply = self._client.messages.create(**request)
        except anthropic.AnthropicError as exc:
            raise LLMError(f"Anthropic API call failed: {exc}") from exc

        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        for block in reply.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCall(call_id=block.id, name=block.name, arguments=dict(block.input))
                )
        return LLMResponse(
            text="\n".join(text_parts).strip(),
            tool_calls=tool_calls,
            stop_reason=reply.stop_reason or "end_turn",
        )


# ------------------------------------------------------------------------ mock mode

# Both prompts name the reply language as "in English" or "in Arabic"; the mock keys on it.
ARABIC_MARKER = "in Arabic"

MOCK_SCRIPT: tuple[tuple[str, dict[str, Any]], ...] = (
    ("load_service_data", {}),
    ("analyze_waste", {"group_by": "camp"}),
    ("forecast_demand", {"service_level": 0.95}),
    ("plan_redistribution", {}),
    ("get_policy_context", {}),
    ("recommend_actions", {}),
)

MOCK_PLAN: dict[Language, list[str]] = {
    "en": [
        "Load and validate the meal-service data (load_service_data).",
        "Measure over-preparation and plate waste by camp (analyze_waste).",
        "Forecast demand and size preparation for the next service date (forecast_demand).",
        "Allocate expected surplus to charities (plan_redistribution).",
        "Fetch published national figures with sources (get_policy_context).",
        "Build SDG-tagged recommendations with confidence notes (recommend_actions).",
        "Assemble the structured report (generate_report).",
    ],
    "ar": [
        "تحميل بيانات خدمات الإعاشة والتحقق من صحتها (load_service_data).",
        "قياس الإعداد الزائد وهدر الأطباق لكل مخيم (analyze_waste).",
        "التنبؤ بالطلب وتحديد كميات الإعداد ليوم الخدمة القادم (forecast_demand).",
        "توزيع الفائض المتوقع على الجمعيات (plan_redistribution).",
        "جلب الأرقام الوطنية المنشورة مع مصادرها (get_policy_context).",
        "صياغة توصيات موسومة بغايات التنمية المستدامة مع ملاحظات الثقة (recommend_actions).",
        "إعداد التقرير المنظَّم (generate_report).",
    ],
}

MOCK_SUMMARY: dict[Language, str] = {
    "en": (
        "Across {days} and {camps}, {overprep}% of prepared meals were not served. "
        "For {day}, the forecast is {forecast:,} meals; preparing {recommended:,} instead of "
        "the habitual {habitual:,} would avoid about {avoided:,} meals while keeping a {level} "
        "service level. {placed:,} of {surplus:,} expected surplus meals can be placed with "
        "charities, subject to food-safety inspection. Details and SDG tags follow."
    ),
    "ar": (
        "على مدى {days} في {camps}، لم يُقدَّم {overprep}% من الوجبات المُعدّة. "
        "ليوم {day} يُتوقع تقديم {forecast:,} وجبة؛ وإعداد {recommended:,} وجبة بدلًا من "
        "{habitual:,} المعتادة يجنّب إعداد نحو {avoided:,} وجبة مع الحفاظ على مستوى خدمة {level}. "
        "ويمكن توجيه {placed:,} من أصل {surplus:,} وجبة فائضة متوقعة إلى الجمعيات بعد موافقة "
        "مراقب سلامة الغذاء. التفاصيل ووسوم أهداف التنمية المستدامة في التقرير."
    ),
}

MOCK_CLOSING: dict[Language, str] = {
    "en": (
        "The report is ready. It contains the preparation plan, the redistribution plan and "
        "the recommendations, each tagged with its SDG target and a confidence note. "
        "All actions require human approval."
    ),
    "ar": (
        "التقرير جاهز، ويتضمن خطة الإعداد وخطة إعادة التوزيع والتوصيات، وكل توصية موسومة "
        "بغاية التنمية المستدامة المرتبطة بها مع ملاحظة عن درجة الثقة. جميع الإجراءات تتطلب "
        "موافقة بشرية."
    ),
}


MOCK_FAILURE: dict[Language, str] = {
    "en": "I could not complete the analysis because a tool failed: {error}",
    "ar": "تعذّر إكمال التحليل بسبب فشل إحدى الأدوات: {error}",
}


class MockClient:
    """Offline stand-in for the language model.

    It replays a fixed sequence of tool calls and fills canned text templates with
    figures taken from the tool results already in the conversation. The reply
    language is read from the prompt. If a tool fails, it stops and reports the
    error instead of continuing the script. It needs no API key and is fully
    deterministic, which is what tests and CI rely on.
    """

    def complete(
        self, *, system: str, messages: list[Message], tools: list[dict[str, Any]]
    ) -> LLMResponse:
        """Return the next scripted reply for the conversation so far."""
        language: Language = "ar" if ARABIC_MARKER in system else "en"
        if not tools:
            plan = json.dumps(MOCK_PLAN[language], ensure_ascii=False)
            return LLMResponse(text=plan, tool_calls=[], stop_reason="end_turn")

        latest = _blocks(messages[-1], "tool_result") if messages else []
        failures = [block for block in latest if block.get("is_error")]
        if failures:
            text = MOCK_FAILURE[language].format(error=failures[0]["content"])
            return LLMResponse(text=text, tool_calls=[], stop_reason="end_turn")
        results = _tool_results_by_name(messages)
        step = sum(len(_blocks(message, "tool_result")) for message in messages)
        if step < len(MOCK_SCRIPT):
            name, arguments = MOCK_SCRIPT[step]
        elif step == len(MOCK_SCRIPT):
            name = "generate_report"
            arguments = {"executive_summary": _mock_summary(results, language)}
        else:
            return LLMResponse(text=MOCK_CLOSING[language], tool_calls=[], stop_reason="end_turn")
        call = ToolCall(call_id=f"mock_call_{step + 1}", name=name, arguments=arguments)
        return LLMResponse(text="", tool_calls=[call], stop_reason="tool_use")


def _blocks(message: Message, block_type: str) -> list[dict[str, Any]]:
    content = message.get("content")
    if not isinstance(content, list):
        return []
    return [block for block in content if block.get("type") == block_type]


def _tool_results_by_name(messages: list[Message]) -> dict[str, Any]:
    """Map tool name to its latest successful, JSON-decoded result."""
    names = {
        block["id"]: block["name"] for message in messages for block in _blocks(message, "tool_use")
    }
    results: dict[str, Any] = {}
    for message in messages:
        for block in _blocks(message, "tool_result"):
            if block.get("is_error"):
                continue
            name = names.get(block.get("tool_use_id", ""))
            if name is not None:
                results[name] = json.loads(block["content"])
    return results


def _mock_summary(results: dict[str, Any], language: Language) -> str:
    try:
        dataset = results["load_service_data"]
        waste = results["analyze_waste"]
        forecast = results["forecast_demand"]
        plan = results["plan_redistribution"]
    except KeyError as exc:
        raise LLMError(f"Mock client cannot summarise: no result for tool {exc}.") from exc
    return MOCK_SUMMARY[language].format(
        days=counted(dataset["days"], "day", language),
        camps=counted(len(dataset["camps"]), "camp", language),
        overprep=waste["overall"]["overprep_rate_pct"],
        day=forecast["target_date"],
        forecast=forecast["total_forecast_meals"],
        recommended=forecast["total_recommended_prep"],
        habitual=forecast["total_habitual_prep"],
        avoided=forecast["total_meals_avoided"],
        level=f"{forecast['service_level']:.0%}",
        placed=plan["allocated_meals"],
        surplus=plan["surplus_meals"],
    )
