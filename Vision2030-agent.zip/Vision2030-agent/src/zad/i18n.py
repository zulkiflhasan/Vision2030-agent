"""Language detection and the fixed Arabic/English text used in reports.

All user-facing strings produced by tools live here, in both languages, so that
numbers and wording are identical regardless of what the language model writes.
"""

from __future__ import annotations

from zad.models import Confidence, Language

ARABIC_RANGES = (("؀", "ۿ"), ("ݐ", "ݿ"), ("ﭐ", "﷿"), ("ﹰ", "﻿"))
ARABIC_THRESHOLD = 0.5


def detect_language(text: str) -> Language:
    """Return ``"ar"`` when at least half of the letters in ``text`` are Arabic."""
    letters = [char for char in text if char.isalpha()]
    if not letters:
        return "en"
    arabic = sum(1 for char in letters if any(low <= char <= high for low, high in ARABIC_RANGES))
    return "ar" if arabic / len(letters) >= ARABIC_THRESHOLD else "en"


LABELS: dict[Language, dict[str, str]] = {
    "en": {
        "title": "Zad — Pilgrim Catering Food-Waste Report",
        "question": "Question",
        "mode": "Mode",
        "mode_mock": "mock (offline, canned language-model responses)",
        "mode_live": "live (Anthropic Claude)",
        "data": "Data",
        "summary": "Executive summary",
        "kpis": "Key figures",
        "metric": "Metric",
        "value": "Value",
        "period": "Period analysed",
        "records": "Meal services analysed",
        "prepared": "Meals prepared",
        "served": "Meals served",
        "overprep": "Over-preparation rate",
        "plate_waste": "Plate waste",
        "per_meal": "per served meal",
        "hotspots": "Over-preparation hotspots",
        "forecast": "Forecast and preparation plan for",
        "camp": "Camp",
        "forecast_meals": "Forecast meals",
        "recommended": "Recommended preparation",
        "habitual": "Habitual preparation",
        "avoided": "Meals avoided",
        "total": "Total",
        "backtest": "Back-test error (MAPE)",
        "kg": "kg",
        "g": "g",
        "service_level": "Service level",
        "redistribution": "Surplus redistribution plan",
        "charity": "Charity",
        "meals": "Meals",
        "distance": "Distance (km)",
        "cold_chain": "Cold chain",
        "yes": "yes",
        "no": "no",
        "placed": "Surplus placed",
        "unplaced": "not placed",
        "inspector": "Every hand-over requires approval by a food-safety inspector.",
        "recommendations": "Recommendations",
        "action": "Action",
        "impact": "Expected impact",
        "vision": "Vision 2030 objective",
        "sdg": "SDG target",
        "indicator": "indicator",
        "confidence": "Confidence",
        "approval": "Human approval required",
        "context": "National context (published figures)",
        "source": "Source",
        "plan": "Agent plan",
        "trace": "Tool calls",
        "limitations": "Limitations",
        "high": "high",
        "medium": "medium",
        "low": "low",
    },
    "ar": {
        "title": "زاد — تقرير الحد من هدر الطعام في إعاشة ضيوف الرحمن",
        "question": "السؤال",
        "mode": "وضع التشغيل",
        "mode_mock": "تجريبي (دون اتصال، ردود جاهزة للنموذج اللغوي)",
        "mode_live": "مباشر (Anthropic Claude)",
        "data": "البيانات",
        "summary": "الملخص التنفيذي",
        "kpis": "أهم الأرقام",
        "metric": "المؤشر",
        "value": "القيمة",
        "period": "الفترة المحلَّلة",
        "records": "خدمات الإعاشة المحلَّلة",
        "prepared": "الوجبات المُعدّة",
        "served": "الوجبات المقدَّمة",
        "overprep": "نسبة الإعداد الزائد",
        "plate_waste": "هدر الأطباق",
        "per_meal": "لكل وجبة مقدَّمة",
        "hotspots": "المخيمات الأعلى في الإعداد الزائد",
        "forecast": "التنبؤ وخطة الإعداد ليوم",
        "camp": "المخيم",
        "forecast_meals": "الوجبات المتوقعة",
        "recommended": "الإعداد الموصى به",
        "habitual": "الإعداد المعتاد",
        "avoided": "وجبات يمكن تجنّب إعدادها",
        "total": "الإجمالي",
        "backtest": "خطأ الاختبار الرجعي (MAPE)",
        "kg": "كجم",
        "g": "غ",
        "service_level": "مستوى الخدمة",
        "redistribution": "خطة إعادة توزيع الفائض",
        "charity": "الجمعية",
        "meals": "الوجبات",
        "distance": "المسافة (كم)",
        "cold_chain": "نقل مبرَّد",
        "yes": "نعم",
        "no": "لا",
        "placed": "الفائض الموزَّع",
        "unplaced": "غير موزَّع",
        "inspector": "كل عملية تسليم تتطلب موافقة مراقب سلامة الغذاء.",
        "recommendations": "التوصيات",
        "action": "الإجراء",
        "impact": "الأثر المتوقع",
        "vision": "هدف رؤية 2030",
        "sdg": "غاية التنمية المستدامة",
        "indicator": "المؤشر",
        "confidence": "درجة الثقة",
        "approval": "تتطلب موافقة بشرية",
        "context": "السياق الوطني (أرقام منشورة)",
        "source": "المصدر",
        "plan": "خطة الوكيل",
        "trace": "استدعاءات الأدوات",
        "limitations": "حدود التقرير",
        "high": "عالية",
        "medium": "متوسطة",
        "low": "منخفضة",
    },
}

LIMITATIONS: dict[Language, list[str]] = {
    "en": [
        "Figures are operational estimates. They contribute to, but are not, official SDG "
        "indicator values.",
        "The forecast is a simple weighted average with a short history; it does not model "
        "ritual-day effects or weather.",
        "Food-safety clearance, special diets and the choice of beneficiaries are decided by "
        "people, not by this agent.",
        "Charity distances are single values per charity, not per camp.",
    ],
    "ar": [
        "الأرقام تقديرات تشغيلية تُسهم في مؤشرات أهداف التنمية المستدامة الرسمية لكنها ليست "
        "قيمًا رسمية لها.",
        "التنبؤ متوسط مرجَّح بسيط يعتمد على سجل قصير، ولا يأخذ في الحسبان أثر أيام المناسك أو الطقس.",
        "إجازة سلامة الغذاء والوجبات الخاصة واختيار المستفيدين قرارات بشرية لا يتخذها هذا الوكيل.",
        "مسافة كل جمعية قيمة واحدة لا تختلف باختلاف المخيم.",
    ],
}

VISION_OBJECTIVES: dict[str, dict[Language, str]] = {
    "pep_quality": {
        "en": "Pilgrim Experience Program — Providing high-quality services for Hajj and "
        "Umrah pilgrims",
        "ar": "برنامج خدمة ضيوف الرحمن — تقديم خدمات ذات جودة عالية للحجاج والمعتمرين",
    },
    "ntp_food": {
        "en": "National Transformation Program — Objective 19: Ensure development and food "
        "security",
        "ar": "برنامج التحول الوطني — الهدف 19: ضمان تحقيق الأمن التنموي والغذائي",
    },
    "ntp_pollution": {
        "en": "National Transformation Program — Objective 16: Reduce all types of pollution",
        "ar": "برنامج التحول الوطني — الهدف 16: الحد من التلوث بمختلف أنواعه",
    },
}


# Arabic counted-noun forms: (one, two, plural for 3-10, singular for 11-99, singular for 100+)
ARABIC_NOUNS: dict[str, tuple[str, str, str, str, str]] = {
    "day": ("يوم واحد", "يومين", "أيام", "يومًا", "يوم"),
    "camp": ("مخيم واحد", "مخيمين", "مخيمات", "مخيمًا", "مخيم"),
    "charity": ("جمعية واحدة", "جمعيتين", "جمعيات", "جمعية", "جمعية"),
    "record": ("سجل واحد", "سجلين", "سجلات", "سجلًّا", "سجل"),
}
ENGLISH_NOUNS: dict[str, tuple[str, str]] = {
    "day": ("day", "days"),
    "camp": ("camp", "camps"),
    "charity": ("charity", "charities"),
    "record": ("record", "records"),
}


def counted(number: int, noun: str, language: Language) -> str:
    """Return ``number`` with ``noun`` in the grammatical form the language requires.

    Arabic nouns change form with the number (1, 2, 3-10, 11-99, 100+); English
    only distinguishes singular from plural.
    """
    if language == "en":
        singular, plural = ENGLISH_NOUNS[noun]
        return f"{number:,} {singular if number == 1 else plural}"
    one, two, few, many, hundreds = ARABIC_NOUNS[noun]
    if number == 1:
        return one
    if number == 2:
        return two
    remainder = number % 100
    if 3 <= remainder <= 10:
        return f"{number:,} {few}"
    if 11 <= remainder <= 99:
        return f"{number:,} {many}"
    return f"{number:,} {hundreds}"


def confidence_label(confidence: Confidence, language: Language) -> str:
    """Return the localised word for a confidence level."""
    return LABELS[language][confidence]
