"""Typed data models shared by the tools, the agent loop and the report renderer.

Input records forbid extra fields on purpose: a meal-service file that carries
columns the agent does not need (names, nationalities, permit numbers) is rejected
at load time, which keeps personal data out of the pipeline by construction.
"""

from __future__ import annotations

from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Language = Literal["en", "ar"]
MealType = Literal["breakfast", "lunch", "dinner"]
Confidence = Literal["high", "medium", "low"]
GroupBy = Literal["camp", "site", "meal_type", "date"]


class StrictModel(BaseModel):
    """Base model that rejects unknown fields and is immutable after validation."""

    model_config = ConfigDict(extra="forbid", frozen=True)


# --------------------------------------------------------------------------- inputs


class MealServiceRecord(StrictModel):
    """One meal service at one camp on one day (aggregate counts only)."""

    service_date: date
    camp_id: str = Field(min_length=1)
    site: str = Field(min_length=1)
    meal_type: MealType
    registered_pilgrims: int = Field(gt=0)
    meals_prepared: int = Field(ge=0)
    meals_served: int = Field(ge=0)
    plate_waste_kg: float = Field(ge=0)

    @model_validator(mode="after")
    def _served_not_above_prepared(self) -> MealServiceRecord:
        if self.meals_served > self.meals_prepared:
            raise ValueError("meals_served cannot exceed meals_prepared")
        return self

    @property
    def unserved_meals(self) -> int:
        """Meals prepared but never served (the over-preparation surplus)."""
        return self.meals_prepared - self.meals_served


class OccupancyPlan(StrictModel):
    """Planned registered headcount for a camp on a future service date."""

    service_date: date
    camp_id: str = Field(min_length=1)
    registered_pilgrims: int = Field(gt=0)


class Charity(StrictModel):
    """A food bank or charity able to collect surplus meals."""

    charity_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    daily_capacity_meals: int = Field(ge=0)
    distance_km: float = Field(ge=0)
    has_cold_chain: bool


# --------------------------------------------------------------------- tool outputs


class DatasetSummary(StrictModel):
    """Result of ``load_service_data``."""

    records: int
    camps: list[str]
    sites: list[str]
    first_date: date
    last_date: date
    days: int
    total_meals_prepared: int
    total_meals_served: int
    total_plate_waste_kg: float
    charities: int
    planned_dates: list[date]
    provenance: str
    provenance_ar: str | None = None


class WasteGroup(StrictModel):
    """Waste metrics for one group (a camp, a site, a meal type or a date)."""

    key: str
    meals_prepared: int
    meals_served: int
    unserved_meals: int
    overprep_rate_pct: float
    plate_waste_kg: float
    plate_waste_g_per_served_meal: float


class WasteAnalysis(StrictModel):
    """Result of ``analyze_waste``."""

    group_by: GroupBy
    overall: WasteGroup
    groups: list[WasteGroup]
    hotspots: list[str]


class ForecastItem(StrictModel):
    """Forecast and preparation sizing for one camp and meal on the target date."""

    camp_id: str
    meal_type: MealType
    registered_pilgrims: int
    forecast_meals: int
    lower_meals: int
    upper_meals: int
    recommended_prep: int
    habitual_prep: int
    meals_avoided: int
    expected_surplus: int
    history_days: int


class DemandForecast(StrictModel):
    """Result of ``forecast_demand``."""

    target_date: date
    service_level: float
    method: str
    items: list[ForecastItem]
    total_forecast_meals: int
    total_recommended_prep: int
    total_habitual_prep: int
    total_meals_avoided: int
    total_expected_surplus: int
    backtest_days: int
    backtest_mape_pct: float
    confidence: Confidence


class Allocation(StrictModel):
    """Surplus meals from one camp assigned to one charity."""

    camp_id: str
    charity_id: str
    charity_name: str
    meals: int
    distance_km: float
    cold_chain: bool


class RedistributionPlan(StrictModel):
    """Result of ``plan_redistribution``."""

    target_date: date
    surplus_meals: int
    allocated_meals: int
    unallocated_meals: int
    placement_rate_pct: float
    allocations: list[Allocation]
    rule: str
    requires_inspector_approval: bool = True


class Recommendation(StrictModel):
    """One action proposed by the agent.

    ``sdg_target``, ``sdg_indicator`` and ``confidence_note`` are required fields,
    so a recommendation without an SDG tag or a confidence note cannot be built.
    """

    rec_id: str
    title: str
    action: str
    expected_impact: str
    vision2030_objective: str
    sdg_target: str = Field(pattern=r"^\d{1,2}\.[0-9a-c]{1,2}$")
    sdg_indicator: str = Field(pattern=r"^\d{1,2}\.[0-9a-c]{1,2}\.\d(\([ab]\))?$")
    confidence: Confidence
    confidence_note: str = Field(min_length=10)
    requires_human_approval: bool = True


class SourcedFact(StrictModel):
    """A published figure with the URL it was taken from."""

    fact_id: str
    statement_en: str
    statement_ar: str
    source_name: str
    source_url: str = Field(pattern=r"^https://")


class PolicyContext(StrictModel):
    """Result of ``get_policy_context``."""

    facts: list[SourcedFact]


class ToolCallRecord(StrictModel):
    """Audit-trail entry for one tool call made by the agent."""

    step: int
    tool: str
    arguments: dict[str, Any]
    ok: bool
    summary: str


class AgentReport(StrictModel):
    """The structured report returned by every agent run."""

    title: str
    language: Language
    mode: Literal["mock", "live"]
    question: str
    plan: list[str]
    executive_summary: str
    dataset: DatasetSummary
    waste: WasteAnalysis
    forecast: DemandForecast
    redistribution: RedistributionPlan
    recommendations: list[Recommendation] = Field(min_length=1)
    context: PolicyContext
    limitations: list[str]
    trace: list[ToolCallRecord] = Field(default_factory=list)
