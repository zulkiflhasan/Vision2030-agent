"""Command-line interface.

Examples:
    zad run "How can we cut food waste in the Mina camps tomorrow?" --mock
    zad run "كيف نقلل هدر الطعام في مخيمات منى غدًا؟" --mock
    zad tools
"""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer

from zad import __version__
from zad.agent import Agent, AgentError, AgentResult
from zad.config import ConfigError, load_settings
from zad.llm import AnthropicClient, LLMClient, LLMError, MockClient
from zad.models import Language
from zad.tools.registry import TOOLS
from zad.tools.report import render_markdown

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Zad: an AI agent that reduces food waste in Hajj and Umrah catering "
    "(Saudi Vision 2030, UN SDG 12.3).",
)


class LanguageChoice(StrEnum):
    """Values accepted by ``--lang``."""

    auto = "auto"
    en = "en"
    ar = "ar"


LANGUAGE_BY_CHOICE: dict[LanguageChoice, Language] = {
    LanguageChoice.en: "en",
    LanguageChoice.ar: "ar",
}


def run_agent(
    question: str,
    *,
    mock: bool,
    language: Language | None = None,
    data_dir: Path | None = None,
) -> AgentResult:
    """Build the client and agent from settings and answer ``question``.

    Shared by the CLI and the Streamlit app.

    Raises:
        ConfigError, LLMError, AgentError: with a message suitable for end users.
    """
    settings = load_settings(data_dir)
    client: LLMClient
    if mock:
        client = MockClient()
    else:
        client = AnthropicClient(
            api_key=settings.api_key, model=settings.model, max_tokens=settings.max_tokens
        )
    agent = Agent(
        client,
        data_dir=settings.data_dir,
        mode="mock" if mock else "live",
        max_steps=settings.max_steps,
    )
    return agent.run(question, language)


def _version(value: bool) -> None:
    if value:
        typer.echo(f"zad {__version__}")
        raise typer.Exit


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option("--version", callback=_version, is_eager=True, help="Show the version."),
    ] = False,
) -> None:
    """Zad command-line interface."""


@app.command()
def run(
    question: Annotated[str, typer.Argument(help="Your question, in Arabic or English.")],
    mock: Annotated[
        bool,
        typer.Option("--mock", help="Run offline with canned model responses (no API key)."),
    ] = False,
    lang: Annotated[
        LanguageChoice, typer.Option("--lang", help="Reply language; 'auto' detects it.")
    ] = LanguageChoice.auto,
    data_dir: Annotated[
        Path | None,
        typer.Option("--data-dir", help="Directory with the CSV inputs (default: data/sample)."),
    ] = None,
    output: Annotated[
        Path | None, typer.Option("--output", "-o", help="Also write the Markdown report here.")
    ] = None,
    json_output: Annotated[
        Path | None, typer.Option("--json", help="Also write the structured report as JSON here.")
    ] = None,
) -> None:
    """Answer a question and print the structured report as Markdown."""
    language = LANGUAGE_BY_CHOICE.get(lang)
    try:
        result = run_agent(question, mock=mock, language=language, data_dir=data_dir)
    except (ConfigError, LLMError, AgentError) as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1) from exc

    markdown = render_markdown(result.report)
    typer.echo(markdown)
    if result.final_message:
        typer.echo(f"---\n{result.final_message}")
    if output is not None:
        output.write_text(markdown, encoding="utf-8")
    if json_output is not None:
        json_output.write_text(result.report.model_dump_json(indent=2) + "\n", encoding="utf-8")


@app.command()
def tools() -> None:
    """List the tools the agent can call."""
    for spec in TOOLS:
        typer.echo(f"{spec.name}\n    {spec.description}")


if __name__ == "__main__":
    app()
