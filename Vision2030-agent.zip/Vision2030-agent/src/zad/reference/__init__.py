"""Verified reference facts bundled with the package (see ``national_context.json``)."""
