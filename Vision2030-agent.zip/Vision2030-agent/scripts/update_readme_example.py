"""Refresh the "Example run" block in README.md with the real mock-mode CLI output.

Usage:
    python scripts/update_readme_example.py          # rewrite README.md
    python scripts/update_readme_example.py --check  # exit 1 if README.md is stale
"""

from __future__ import annotations

import sys
from pathlib import Path

from typer.testing import CliRunner

from zad.cli import app

README = Path(__file__).resolve().parent.parent / "README.md"
QUESTION = "How many meals should we prepare tomorrow, and where should the surplus go?"
START = "<!-- example-output:start -->"
END = "<!-- example-output:end -->"


def cli_output() -> str:
    """Run the CLI in mock mode and return exactly what it prints."""
    result = CliRunner().invoke(app, ["run", QUESTION, "--mock"])
    if result.exit_code != 0:
        raise RuntimeError(f"CLI failed with exit code {result.exit_code}:\n{result.output}")
    return result.output.rstrip("\n")


def render(readme_text: str) -> str:
    """Return ``readme_text`` with the example block replaced by the current output."""
    head, separator, rest = readme_text.partition(START)
    _, end_separator, tail = rest.partition(END)
    if not separator or not end_separator:
        raise RuntimeError("README.md is missing the example-output markers.")
    block = (
        f"<details open>\n<summary>Report</summary>\n\n````text\n{cli_output()}\n````\n\n</details>"
    )
    return f"{head}{START}\n{block}\n{END}{tail}"


def main() -> int:
    """Rewrite or check README.md; return the process exit code."""
    current = README.read_text(encoding="utf-8")
    updated = render(current)
    if "--check" in sys.argv[1:]:
        if current != updated:
            print("README.md example output is stale. Run scripts/update_readme_example.py.")
            return 1
        print("README.md example output is current.")
        return 0
    README.write_text(updated, encoding="utf-8")
    print("README.md example output updated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
