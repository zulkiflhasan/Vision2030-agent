from __future__ import annotations

import csv
import json
from collections.abc import Callable
from pathlib import Path

import pytest

from zad.tools.context import ToolContext

REPO_ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DIR = REPO_ROOT / "data" / "sample"

MEAL_HEADER = [
    "service_date",
    "camp_id",
    "site",
    "meal_type",
    "registered_pilgrims",
    "meals_prepared",
    "meals_served",
    "plate_waste_kg",
]
# Two camps, three days, one meal. Camp A always serves 80% and prepares 100%;
# camp B always serves 90% and prepares 100%. Ratios are constant, so forecasts are exact.
TINY_MEALS = [
    ["2025-01-01", "A", "Mina", "lunch", 1000, 1000, 800, 40.0],
    ["2025-01-02", "A", "Mina", "lunch", 1000, 1000, 800, 40.0],
    ["2025-01-03", "A", "Mina", "lunch", 1000, 1000, 800, 40.0],
    ["2025-01-01", "B", "Makkah", "lunch", 500, 500, 450, 9.0],
    ["2025-01-02", "B", "Makkah", "lunch", 500, 500, 450, 9.0],
    ["2025-01-03", "B", "Makkah", "lunch", 500, 500, 450, 9.0],
]
TINY_PLAN = [["2025-01-04", "A", 2000], ["2025-01-04", "B", 500]]
TINY_CHARITIES = [
    ["C-NEAR", "Near", 10, 2.0, "false"],
    ["C-FAR-COLD", "Far cold", 100, 40.0, "true"],
    ["C-FAR-WARM", "Far warm", 1000, 40.0, "false"],
]

DataDirFactory = Callable[..., Path]


def write_csv(path: Path, header: list[str], rows: list[list[object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        writer.writerows(rows)


@pytest.fixture
def sample_dir() -> Path:
    return SAMPLE_DIR


@pytest.fixture
def ctx(sample_dir: Path) -> ToolContext:
    return ToolContext(data_dir=sample_dir, question="test question")


@pytest.fixture
def make_data_dir(tmp_path: Path) -> DataDirFactory:
    """Build a small data directory; any file's rows can be overridden."""

    def factory(
        meals: list[list[object]] | None = None,
        plan: list[list[object]] | None = None,
        charities: list[list[object]] | None = None,
        meal_header: list[str] | None = None,
        manifest: dict[str, object] | None = None,
    ) -> Path:
        write_csv(tmp_path / "meal_service.csv", meal_header or MEAL_HEADER, meals or TINY_MEALS)
        write_csv(
            tmp_path / "occupancy_plan.csv",
            ["service_date", "camp_id", "registered_pilgrims"],
            TINY_PLAN if plan is None else plan,
        )
        write_csv(
            tmp_path / "charities.csv",
            ["charity_id", "name", "daily_capacity_meals", "distance_km", "has_cold_chain"],
            TINY_CHARITIES if charities is None else charities,
        )
        if manifest is not None:
            (tmp_path / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        return tmp_path

    return factory


@pytest.fixture
def tiny_ctx(make_data_dir: DataDirFactory) -> ToolContext:
    return ToolContext(data_dir=make_data_dir(), question="tiny")
