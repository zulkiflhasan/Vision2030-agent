from __future__ import annotations

from datetime import date

import pytest

from tests.conftest import DataDirFactory
from zad.tools.context import ToolContext, ToolError
from zad.tools.forecaster import ForecastDemandInput, forecast_demand
from zad.tools.recommender import RecommendActionsInput, recommend_actions
from zad.tools.redistribution import (
    COLD_CHAIN_KM,
    PlanRedistributionInput,
    plan_redistribution,
)

OFFICIAL_TAGS = {
    "12.3": "12.3.1(b)",
    "2.1": "2.1.2",
    "12.5": "12.5.1",
    "11.6": "11.6.1",
}


def test_greedy_allocation_respects_capacity_and_cold_chain(tiny_ctx: ToolContext) -> None:
    plan = plan_redistribution(tiny_ctx, PlanRedistributionInput())
    # Surplus: camp A 32, camp B 9 (ceil(450*1.02)=459). A first: 10 to C-NEAR, 22 to C-FAR-COLD.
    assert plan.surplus_meals == 41
    assert [(a.camp_id, a.charity_id, a.meals) for a in plan.allocations] == [
        ("A", "C-NEAR", 10),
        ("A", "C-FAR-COLD", 22),
        ("B", "C-FAR-COLD", 9),
    ]
    assert plan.unallocated_meals == 0
    assert plan.placement_rate_pct == 100.0
    assert plan.requires_inspector_approval is True
    # The far charity without refrigerated transport is never used, despite its capacity.
    assert all(a.charity_id != "C-FAR-WARM" for a in plan.allocations)


def test_sample_plan_conserves_meals_and_respects_limits(ctx: ToolContext) -> None:
    plan = plan_redistribution(ctx, PlanRedistributionInput())
    capacity = {charity.charity_id: charity.daily_capacity_meals for charity in ctx.charities}
    used: dict[str, int] = {}
    for allocation in plan.allocations:
        used[allocation.charity_id] = used.get(allocation.charity_id, 0) + allocation.meals
        assert allocation.meals > 0
        assert allocation.distance_km <= COLD_CHAIN_KM or allocation.cold_chain
    assert all(meals <= capacity[charity_id] for charity_id, meals in used.items())
    assert plan.allocated_meals + plan.unallocated_meals == plan.surplus_meals
    assert ctx.forecast is not None
    assert plan.surplus_meals == ctx.forecast.total_expected_surplus


def test_insufficient_capacity_leaves_surplus_unallocated(make_data_dir: DataDirFactory) -> None:
    context = ToolContext(data_dir=make_data_dir(charities=[["C1", "Only", 5, 1.0, "false"]]))
    plan = plan_redistribution(context, PlanRedistributionInput())
    assert (plan.allocated_meals, plan.unallocated_meals) == (5, 36)
    assert plan.placement_rate_pct == 12.2


def test_target_date_change_recomputes_forecast(ctx: ToolContext) -> None:
    forecast_demand(ctx, ForecastDemandInput(service_level=0.9))
    plan = plan_redistribution(ctx, PlanRedistributionInput(target_date=date(2025, 6, 11)))
    assert plan.target_date == date(2025, 6, 11)
    assert ctx.forecast is not None
    assert ctx.forecast.service_level == 0.9


def test_unplanned_date_error_propagates(ctx: ToolContext) -> None:
    with pytest.raises(ToolError, match="No occupancy plan"):
        plan_redistribution(ctx, PlanRedistributionInput(target_date=date(2031, 1, 1)))


@pytest.mark.parametrize("language", ["en", "ar"])
def test_every_recommendation_has_official_sdg_tag_and_confidence_note(
    ctx: ToolContext, language: str
) -> None:
    recommendations = recommend_actions(ctx, RecommendActionsInput(language=language))
    assert [item.rec_id for item in recommendations] == ["R1", "R2", "R3", "R4", "R5"]
    for item in recommendations:
        assert OFFICIAL_TAGS[item.sdg_target] == item.sdg_indicator
        assert len(item.confidence_note) > 30
        assert item.confidence in {"high", "medium", "low"}
        assert item.requires_human_approval is True
        assert item.vision2030_objective
    # The synthetic-data caveat must be part of every confidence note for the sample data.
    marker = "تجريبية" if language == "ar" else "synthetic"
    assert all(marker in item.confidence_note for item in recommendations)


def test_recommendation_numbers_come_from_the_tools(ctx: ToolContext) -> None:
    first = recommend_actions(ctx, RecommendActionsInput(language="en"))[0]
    assert ctx.forecast is not None
    assert f"{ctx.forecast.total_recommended_prep:,}" in first.action
    assert f"{ctx.forecast.total_habitual_prep:,}" in first.action
    assert f"{ctx.forecast.backtest_mape_pct}%" in first.confidence_note


def test_arabic_recommendations_are_in_arabic(ctx: ToolContext) -> None:
    from zad.i18n import detect_language

    for item in recommend_actions(ctx, RecommendActionsInput(language="ar")):
        assert detect_language(item.title) == "ar"
        assert detect_language(item.confidence_note) == "ar"


def test_redistribution_confidence_is_one_step_below_forecast(ctx: ToolContext) -> None:
    recommendations = recommend_actions(ctx, RecommendActionsInput())
    assert ctx.forecast is not None
    assert ctx.forecast.confidence == "high"
    assert recommendations[2].confidence == "medium"


def test_unplaced_surplus_recommendation_only_when_needed(tiny_ctx: ToolContext) -> None:
    recommendations = recommend_actions(tiny_ctx, RecommendActionsInput())
    assert [item.rec_id for item in recommendations] == ["R1", "R2", "R3", "R4"]
    assert "synthetic" not in recommendations[0].confidence_note  # provenance is unknown here


def test_max_items_and_default_language(ctx: ToolContext) -> None:
    ctx.language = "ar"
    recommendations = recommend_actions(ctx, RecommendActionsInput(max_items=2))
    assert len(recommendations) == 2
    assert "ثقة" in recommendations[0].confidence_note
