from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import anthropic
import pytest

from zad.llm import AnthropicClient, LLMError, LLMResponse, MockClient, ToolCall
from zad.tools.registry import anthropic_tool_schemas

SYSTEM_EN = "Language: reply in English."
SYSTEM_AR = "Language: reply in Arabic."


class FakeMessages:
    def __init__(self, reply: Any = None, error: Exception | None = None) -> None:
        self.reply = reply
        self.error = error
        self.requests: list[dict[str, Any]] = []

    def create(self, **request: Any) -> Any:
        self.requests.append(request)
        if self.error is not None:
            raise self.error
        return self.reply


def fake_sdk(reply: Any = None, error: Exception | None = None) -> Any:
    return SimpleNamespace(messages=FakeMessages(reply, error))


def test_live_client_requires_a_key() -> None:
    with pytest.raises(LLMError, match=r"ANTHROPIC_API_KEY is not set.*--mock"):
        AnthropicClient(api_key=None, model="m", max_tokens=10)


def test_live_client_converts_text_and_tool_use_blocks() -> None:
    reply = SimpleNamespace(
        content=[
            SimpleNamespace(type="text", text="Loading the data."),
            SimpleNamespace(
                type="tool_use", id="toolu_1", name="analyze_waste", input={"group_by": "site"}
            ),
            SimpleNamespace(type="thinking", thinking="ignored"),
        ],
        stop_reason="tool_use",
    )
    sdk = fake_sdk(reply)
    client = AnthropicClient(api_key=None, model="claude-test", max_tokens=123, sdk_client=sdk)
    tools = anthropic_tool_schemas()
    messages = [{"role": "user", "content": "hi"}]

    response = client.complete(system="sys", messages=messages, tools=tools)

    assert response.text == "Loading the data."
    assert response.stop_reason == "tool_use"
    assert response.tool_calls == [
        ToolCall(call_id="toolu_1", name="analyze_waste", arguments={"group_by": "site"})
    ]
    assert sdk.messages.requests == [
        {
            "model": "claude-test",
            "max_tokens": 123,
            "system": "sys",
            "messages": messages,
            "tools": tools,
        }
    ]


def test_live_client_omits_tools_when_none_are_offered() -> None:
    sdk = fake_sdk(
        SimpleNamespace(content=[SimpleNamespace(type="text", text="[]")], stop_reason=None)
    )
    client = AnthropicClient(api_key=None, model="m", max_tokens=10, sdk_client=sdk)
    response = client.complete(system="s", messages=[], tools=[])
    assert "tools" not in sdk.messages.requests[0]
    assert response.stop_reason == "end_turn"


def test_live_client_wraps_api_errors() -> None:
    # Built without __init__ so the test does not depend on the SDK's HTTP library.
    error = anthropic.APIConnectionError.__new__(anthropic.APIConnectionError)
    client = AnthropicClient(
        api_key=None, model="m", max_tokens=10, sdk_client=fake_sdk(error=error)
    )
    with pytest.raises(LLMError, match="Anthropic API call failed"):
        client.complete(system="s", messages=[], tools=[])


def test_response_round_trips_to_wire_format() -> None:
    response = LLMResponse(
        text="t",
        tool_calls=[ToolCall(call_id="c1", name="load_service_data", arguments={})],
        stop_reason="tool_use",
    )
    assert response.as_message() == {
        "role": "assistant",
        "content": [
            {"type": "text", "text": "t"},
            {"type": "tool_use", "id": "c1", "name": "load_service_data", "input": {}},
        ],
    }


def test_mock_planner_reply_follows_prompt_language() -> None:
    client = MockClient()
    english = client.complete(system=SYSTEM_EN, messages=[], tools=[])
    arabic = client.complete(system=SYSTEM_AR, messages=[], tools=[])
    assert english.text.startswith('["Load and validate')
    assert "تحميل" in arabic.text
    assert not english.tool_calls


def test_mock_cannot_summarise_without_tool_results() -> None:
    blocks = [{"type": "tool_result", "tool_use_id": f"x{i}", "content": "{}"} for i in range(6)]
    messages = [{"role": "user", "content": blocks}]
    with pytest.raises(LLMError, match="no result for tool 'load_service_data'"):
        MockClient().complete(system=SYSTEM_EN, messages=messages, tools=anthropic_tool_schemas())


def test_mock_stops_and_reports_when_a_tool_fails() -> None:
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "tool_result", "tool_use_id": "x", "content": "boom", "is_error": True}
            ],
        }
    ]
    reply = MockClient().complete(
        system=SYSTEM_AR, messages=messages, tools=anthropic_tool_schemas()
    )
    assert not reply.tool_calls
    assert reply.text.endswith("boom")
    assert reply.text.startswith("تعذّر")
