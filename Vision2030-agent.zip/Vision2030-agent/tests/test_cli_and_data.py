from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from tests.conftest import REPO_ROOT, SAMPLE_DIR
from zad import __version__
from zad.cli import app
from zad.config import ConfigError, load_settings
from zad.models import AgentReport

runner = CliRunner()
QUESTION = "How many meals should we prepare tomorrow, and where should the surplus go?"


def test_run_mock_prints_report_and_writes_files(tmp_path: Path) -> None:
    markdown_path = tmp_path / "report.md"
    json_path = tmp_path / "report.json"
    result = runner.invoke(
        app, ["run", QUESTION, "--mock", "--output", str(markdown_path), "--json", str(json_path)]
    )
    assert result.exit_code == 0, result.output
    assert "# Zad — Pilgrim Catering Food-Waste Report" in result.output
    assert "`SDG 12.3` (indicator 12.3.1(b))" in result.output
    assert "The report is ready." in result.output
    assert markdown_path.read_text(encoding="utf-8").startswith("# Zad")
    report = AgentReport.model_validate(json.loads(json_path.read_text(encoding="utf-8")))
    assert report.question == QUESTION
    assert len(report.trace) == 7


def test_run_mock_in_arabic_and_forced_language() -> None:
    arabic = runner.invoke(app, ["run", "كم وجبة نُعدّ غدًا؟", "--mock"])
    assert arabic.exit_code == 0, arabic.output
    assert "## التوصيات" in arabic.output
    forced = runner.invoke(app, ["run", QUESTION, "--mock", "--lang", "ar"])
    assert "## التوصيات" in forced.output


def test_live_mode_without_key_fails_with_guidance(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("zad.config.load_dotenv", lambda: False)
    result = runner.invoke(app, ["run", QUESTION])
    assert result.exit_code == 1
    assert "ANTHROPIC_API_KEY is not set" in result.output
    assert "--mock" in result.output


def test_missing_data_dir_fails_cleanly(tmp_path: Path) -> None:
    result = runner.invoke(app, ["run", QUESTION, "--mock", "--data-dir", str(tmp_path / "nope")])
    assert result.exit_code == 1
    assert "Data directory not found" in result.output


def test_tools_and_version_commands() -> None:
    listing = runner.invoke(app, ["tools"])
    assert listing.exit_code == 0
    assert listing.output.count("\n    ") == 7
    assert "forecast_demand" in listing.output
    assert runner.invoke(app, ["--version"]).output.strip() == f"zad {__version__}"


def test_settings_read_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("zad.config.load_dotenv", lambda: False)
    monkeypatch.setenv("ZAD_MODEL", "claude-custom")
    monkeypatch.setenv("ZAD_MAX_STEPS", "5")
    monkeypatch.setenv("ZAD_DATA_DIR", str(SAMPLE_DIR))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "")
    settings = load_settings()
    assert (settings.model, settings.max_steps, settings.data_dir) == (
        "claude-custom",
        5,
        SAMPLE_DIR,
    )
    assert settings.api_key is None
    monkeypatch.setenv("ZAD_MAX_STEPS", "many")
    with pytest.raises(ConfigError, match="ZAD_MAX_STEPS must be an integer"):
        load_settings()
    monkeypatch.setenv("ZAD_MAX_STEPS", "0")
    with pytest.raises(ConfigError, match="must be positive"):
        load_settings()


def test_committed_sample_data_matches_the_generator(tmp_path: Path) -> None:
    spec = importlib.util.spec_from_file_location(
        "generate_sample_data", REPO_ROOT / "scripts" / "generate_sample_data.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.generate(tmp_path)
    for name in ("meal_service.csv", "occupancy_plan.csv", "charities.csv", "manifest.json"):
        assert (tmp_path / name).read_bytes() == (SAMPLE_DIR / name).read_bytes(), name


def test_sample_manifest_declares_synthetic_data_without_personal_data() -> None:
    manifest = json.loads((SAMPLE_DIR / "manifest.json").read_text(encoding="utf-8"))
    assert "synthetic" in manifest["provenance"].lower()
    assert manifest["contains_personal_data"] is False


def test_readme_example_output_is_current() -> None:
    spec = importlib.util.spec_from_file_location(
        "update_readme_example", REPO_ROOT / "scripts" / "update_readme_example.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    assert module.render(readme) == readme, "run: python scripts/update_readme_example.py"


def test_streamlit_app_runs_in_both_languages() -> None:
    testing = pytest.importorskip("streamlit.testing.v1")
    app_test = testing.AppTest.from_file(
        str(REPO_ROOT / "app" / "streamlit_app.py"), default_timeout=60
    ).run()
    assert not app_test.exception
    app_test.button[0].click().run()
    assert not app_test.exception and not app_test.error
    assert app_test.markdown[0].value.startswith("# Zad")
    app_test.radio[0].set_value("العربية").run()
    app_test.button[0].click().run()
    assert not app_test.exception and not app_test.error
    assert 'dir="rtl"' in app_test.markdown[0].value
