from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from zad.agent import Agent, AgentError, parse_plan
from zad.i18n import detect_language
from zad.llm import LLMError, LLMResponse, Message, MockClient, ToolCall
from zad.tools.report import render_markdown

QUESTION_EN = "How many meals should we prepare tomorrow, and where should the surplus go?"
QUESTION_AR = "كم وجبة نُعدّ غدًا وأين يذهب الفائض؟"
EXPECTED_TOOL_ORDER = [
    "load_service_data",
    "analyze_waste",
    "forecast_demand",
    "plan_redistribution",
    "get_policy_context",
    "recommend_actions",
    "generate_report",
]


class ScriptedClient:
    """Replays a fixed list of replies and records what it was sent."""

    def __init__(self, replies: list[LLMResponse]) -> None:
        self._replies = list(replies)
        self.calls: list[dict[str, Any]] = []

    def complete(
        self, *, system: str, messages: list[Message], tools: list[dict[str, Any]]
    ) -> LLMResponse:
        self.calls.append({"system": system, "messages": [*messages], "tools": tools})
        return self._replies.pop(0)


def text(content: str) -> LLMResponse:
    return LLMResponse(text=content, tool_calls=[], stop_reason="end_turn")


def call(name: str, arguments: dict[str, Any], call_id: str = "c1") -> LLMResponse:
    return LLMResponse(
        text="",
        tool_calls=[ToolCall(call_id=call_id, name=name, arguments=arguments)],
        stop_reason="tool_use",
    )


def make_agent(client: Any, sample_dir: Path, **kwargs: Any) -> Agent:
    return Agent(client, data_dir=sample_dir, mode="mock", **kwargs)


# ------------------------------------------------------------- end to end, mock mode


def test_end_to_end_mock_run_in_english(sample_dir: Path) -> None:
    result = make_agent(MockClient(), sample_dir).run(QUESTION_EN)
    report = result.report

    assert report.language == "en"
    assert report.mode == "mock"
    assert report.question == QUESTION_EN
    assert len(report.plan) == 7
    assert [record.tool for record in report.trace] == EXPECTED_TOOL_ORDER
    assert all(record.ok for record in report.trace)
    assert result.model_calls == 9  # 1 planner + 7 tool turns + 1 closing turn

    assert report.dataset.records == 336
    assert report.forecast.total_recommended_prep < report.forecast.total_habitual_prep
    assert report.redistribution.allocated_meals > 0
    assert len(report.recommendations) >= 4
    for item in report.recommendations:
        assert item.sdg_target and item.sdg_indicator and item.confidence_note
    assert {item.sdg_target for item in report.recommendations} >= {"12.3", "2.1", "12.5"}

    # The canned summary is filled with tool figures, not invented ones.
    assert f"{report.forecast.total_recommended_prep:,}" in report.executive_summary
    assert f"{report.waste.overall.overprep_rate_pct}%" in report.executive_summary
    assert "report is ready" in result.final_message

    markdown = render_markdown(report)
    assert markdown.startswith("# Zad")
    assert "`generate_report` — ok" in markdown


def test_end_to_end_mock_run_in_arabic(sample_dir: Path) -> None:
    result = make_agent(MockClient(), sample_dir).run(QUESTION_AR)
    report = result.report
    assert report.language == "ar"
    assert detect_language(report.executive_summary) == "ar"
    assert detect_language(result.final_message) == "ar"
    assert all(detect_language(step) == "ar" for step in report.plan)
    assert all(detect_language(item.action) == "ar" for item in report.recommendations)
    assert render_markdown(report).startswith("# زاد")


def test_mock_runs_are_deterministic_and_language_independent(sample_dir: Path) -> None:
    first = make_agent(MockClient(), sample_dir).run(QUESTION_EN).report
    second = make_agent(MockClient(), sample_dir).run(QUESTION_EN).report
    arabic = make_agent(MockClient(), sample_dir).run(QUESTION_AR).report
    assert first == second
    assert first.forecast == arabic.forecast
    assert first.redistribution == arabic.redistribution


def test_language_can_be_forced(sample_dir: Path) -> None:
    report = make_agent(MockClient(), sample_dir).run(QUESTION_EN, language="ar").report
    assert report.language == "ar"
    assert detect_language(report.executive_summary) == "ar"


# ------------------------------------------------------------------ loop behaviour


def test_tool_errors_are_fed_back_so_the_model_can_recover(sample_dir: Path) -> None:
    client = ScriptedClient(
        [
            text('["step one", "step two"]'),
            call("forecast_demand", {"target_date": "2031-01-01"}, "bad"),
            call("forecast_demand", {}, "good"),
            call("generate_report", {"executive_summary": "Preparation can be cut safely."}, "rep"),
            text("Done."),
        ]
    )
    result = make_agent(client, sample_dir).run(QUESTION_EN)

    error_block = client.calls[2]["messages"][-1]["content"][0]
    assert error_block["tool_use_id"] == "bad"
    assert error_block["is_error"] is True
    assert "No occupancy plan for 2031-01-01" in error_block["content"]
    ok_block = client.calls[3]["messages"][-1]["content"][0]
    assert "is_error" not in ok_block
    assert [(r.tool, r.ok) for r in result.report.trace] == [
        ("forecast_demand", False),
        ("forecast_demand", True),
        ("generate_report", True),
    ]
    assert result.report.plan == ["step one", "step two"]


def test_conversation_alternates_roles_and_pairs_tool_ids(sample_dir: Path) -> None:
    client = ScriptedClient(
        [
            text('["only step"]'),
            call("load_service_data", {}, "id-1"),
            call(
                "generate_report", {"executive_summary": "Preparation can be cut safely."}, "id-2"
            ),
            text("Done."),
        ]
    )
    make_agent(client, sample_dir).run(QUESTION_EN)
    messages = client.calls[-1]["messages"]
    assert [message["role"] for message in messages] == [
        "user",
        "assistant",
        "user",
        "assistant",
        "user",
    ]
    assert QUESTION_EN in messages[0]["content"]
    assert "1. only step" in messages[0]["content"]
    assert messages[1]["content"][0]["id"] == messages[2]["content"][0]["tool_use_id"] == "id-1"
    assert client.calls[0]["tools"] == []  # the planner is offered no tools
    assert len(client.calls[1]["tools"]) == 7
    assert "reply in English" in client.calls[1]["system"]


def test_report_is_built_even_if_the_model_skips_generate_report(sample_dir: Path) -> None:
    closing = "Preparing fewer meals than usual covers demand; surplus goes to charities."
    client = ScriptedClient(
        [text("- look at the data"), call("load_service_data", {}), text(closing)]
    )
    result = make_agent(client, sample_dir).run(QUESTION_EN)
    assert result.report.executive_summary == closing
    assert len(result.report.recommendations) == 5
    assert result.report.plan == ["look at the data"]


def test_run_fails_clearly_without_report_or_summary(sample_dir: Path) -> None:
    client = ScriptedClient([text('["a"]'), text("ok")])
    with pytest.raises(AgentError, match="without calling generate_report"):
        make_agent(client, sample_dir).run(QUESTION_EN)


def test_step_limit_stops_a_looping_model(sample_dir: Path) -> None:
    client = ScriptedClient([text('["a"]')] + [call("get_policy_context", {})] * 3)
    with pytest.raises(AgentError, match="Stopped after 3 model calls"):
        make_agent(client, sample_dir, max_steps=3).run(QUESTION_EN)


def test_model_failure_becomes_agent_error(sample_dir: Path) -> None:
    class FailingClient:
        def complete(self, **_: Any) -> LLMResponse:
            raise LLMError("Anthropic API call failed: boom")

    with pytest.raises(AgentError, match="boom"):
        make_agent(FailingClient(), sample_dir).run(QUESTION_EN)


def test_missing_data_becomes_agent_error(tmp_path: Path) -> None:
    with pytest.raises(AgentError, match="Data file not found"):
        Agent(MockClient(), data_dir=tmp_path, mode="mock").run(QUESTION_EN)


def test_empty_question_and_bad_step_limit_are_rejected(sample_dir: Path) -> None:
    with pytest.raises(AgentError, match="question is empty"):
        make_agent(MockClient(), sample_dir).run("   ")
    with pytest.raises(ValueError, match="max_steps"):
        make_agent(MockClient(), sample_dir, max_steps=0)


# --------------------------------------------------------------------- plan parsing


@pytest.mark.parametrize(
    ("reply", "expected"),
    [
        ('["Load data", "Report"]', ["Load data", "Report"]),
        ('Here is the plan:\n```json\n["a", "b"]\n```', ["a", "b"]),
        ("1. Load data\n2) Forecast\n- Report\n\n", ["Load data", "Forecast", "Report"]),
        ('["خطوة أولى", "خطوة ثانية"]', ["خطوة أولى", "خطوة ثانية"]),
        ("[not json] but a line", ["[not json] but a line"]),
    ],
)
def test_parse_plan(reply: str, expected: list[str]) -> None:
    assert parse_plan(reply) == expected


def test_parse_plan_rejects_empty_reply() -> None:
    with pytest.raises(LLMError, match="empty plan"):
        parse_plan("  \n ")
