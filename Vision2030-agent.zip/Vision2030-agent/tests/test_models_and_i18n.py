from __future__ import annotations

import pytest
from pydantic import ValidationError

from zad.i18n import LABELS, LIMITATIONS, counted, detect_language
from zad.models import MealServiceRecord, Recommendation

VALID_RECORD = {
    "service_date": "2025-01-01",
    "camp_id": "A",
    "site": "Mina",
    "meal_type": "lunch",
    "registered_pilgrims": 100,
    "meals_prepared": 100,
    "meals_served": 80,
    "plate_waste_kg": 4.0,
}
VALID_RECOMMENDATION = {
    "rec_id": "R1",
    "title": "t",
    "action": "a",
    "expected_impact": "i",
    "vision2030_objective": "v",
    "sdg_target": "12.3",
    "sdg_indicator": "12.3.1(b)",
    "confidence": "high",
    "confidence_note": "Back-test error of 3% over 3 days.",
}


def test_record_computes_unserved_meals() -> None:
    assert MealServiceRecord.model_validate(VALID_RECORD).unserved_meals == 20


def test_record_rejects_served_above_prepared() -> None:
    with pytest.raises(ValidationError, match="cannot exceed"):
        MealServiceRecord.model_validate({**VALID_RECORD, "meals_served": 101})


def test_record_rejects_personal_data_columns() -> None:
    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        MealServiceRecord.model_validate({**VALID_RECORD, "nationality": "XX"})


@pytest.mark.parametrize(
    "override",
    [
        {"sdg_target": "SDG 12"},
        {"sdg_target": "12"},
        {"sdg_indicator": "12.3"},
        {"confidence_note": "short"},
        {"confidence": "certain"},
    ],
)
def test_recommendation_requires_valid_sdg_tag_and_confidence_note(override: dict) -> None:
    with pytest.raises(ValidationError):
        Recommendation.model_validate({**VALID_RECOMMENDATION, **override})


def test_recommendation_cannot_omit_sdg_tag_or_note() -> None:
    for field in ("sdg_target", "sdg_indicator", "confidence_note"):
        payload = {key: value for key, value in VALID_RECOMMENDATION.items() if key != field}
        with pytest.raises(ValidationError):
            Recommendation.model_validate(payload)


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("How many meals should we prepare?", "en"),
        ("كم وجبة نُعدّ غدًا؟", "ar"),
        ("كيف نقلل الهدر في MINA-02 غدًا؟", "ar"),
        ("Report for مخيم", "en"),
        ("12345 ?!", "en"),
        ("", "en"),
    ],
)
def test_detect_language(text: str, expected: str) -> None:
    assert detect_language(text) == expected


@pytest.mark.parametrize(
    ("number", "expected"),
    [(1, "يوم واحد"), (2, "يومين"), (3, "3 أيام"), (10, "10 أيام"), (14, "14 يومًا"),
     (100, "100 يوم"), (103, "103 أيام")],
)  # fmt: skip
def test_counted_arabic_follows_number_agreement(number: int, expected: str) -> None:
    assert counted(number, "day", "ar") == expected


def test_counted_english() -> None:
    assert counted(1, "charity", "en") == "1 charity"
    assert counted(1336, "record", "en") == "1,336 records"


def test_both_languages_define_the_same_labels_and_limitations() -> None:
    assert LABELS["en"].keys() == LABELS["ar"].keys()
    assert len(LIMITATIONS["en"]) == len(LIMITATIONS["ar"])
