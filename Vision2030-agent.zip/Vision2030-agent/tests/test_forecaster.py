from __future__ import annotations

from datetime import date

import pytest

from tests.conftest import DataDirFactory
from zad.tools.context import ToolContext, ToolError
from zad.tools.forecaster import (
    ForecastDemandInput,
    confidence_from,
    ew_mean,
    forecast_demand,
    size_preparation,
)


def test_ew_mean_weights_recent_values_more() -> None:
    assert ew_mean([4.0]) == 4.0
    # weights 0.25, 0.5, 1 -> (0.25*1 + 0.5*2 + 1*3) / 1.75
    assert ew_mean([1.0, 2.0, 3.0]) == pytest.approx(4.25 / 1.75)
    with pytest.raises(ValueError, match="at least one"):
        ew_mean([])


def test_size_preparation_applies_floor_and_service_level() -> None:
    assert size_preparation(1000, 0, 0.95) == 1020  # zero variance -> 2% floor buffer
    assert size_preparation(1000, 100, 0.95) == 1165  # 1000 + 1.645 * 100 = 1164.5 -> ceil
    assert size_preparation(1000, 100, 0.5) == 1020  # z = 0 -> floor still applies


def test_constant_attendance_gives_exact_forecast(tiny_ctx: ToolContext) -> None:
    result = forecast_demand(tiny_ctx, ForecastDemandInput())
    assert result.target_date == date(2025, 1, 4)
    items = {item.camp_id: item for item in result.items}
    # Camp A: 80% of 2000 planned = 1600; habitual prep 100% = 2000; recommended = ceil(1600*1.02)
    assert items["A"].forecast_meals == 1600
    assert items["A"].recommended_prep == 1632
    assert items["A"].habitual_prep == 2000
    assert items["A"].meals_avoided == 368
    assert items["A"].expected_surplus == 32
    assert items["B"].forecast_meals == 450
    assert result.total_forecast_meals == 2050
    assert result.backtest_mape_pct == 0.0
    assert result.confidence == "medium"  # perfect back-test, but only 3 days of history


def test_never_recommends_less_than_forecast_on_sample_data(ctx: ToolContext) -> None:
    result = forecast_demand(ctx, ForecastDemandInput())
    assert len(result.items) == 24  # 8 camps x 3 meals
    assert all(item.recommended_prep >= item.forecast_meals for item in result.items)
    assert all(item.lower_meals <= item.forecast_meals <= item.upper_meals for item in result.items)
    assert result.total_recommended_prep < result.total_habitual_prep
    assert 0 < result.backtest_mape_pct < 10
    assert result.backtest_days == 3


def test_higher_service_level_prepares_more(ctx: ToolContext) -> None:
    low = forecast_demand(ctx, ForecastDemandInput(service_level=0.8)).total_recommended_prep
    high = forecast_demand(ctx, ForecastDemandInput(service_level=0.99)).total_recommended_prep
    assert high > low


def test_second_planned_date_can_be_forecast(ctx: ToolContext) -> None:
    result = forecast_demand(ctx, ForecastDemandInput(target_date=date(2025, 6, 11)))
    assert result.target_date == date(2025, 6, 11)


def test_unplanned_date_is_an_error_listing_planned_dates(ctx: ToolContext) -> None:
    with pytest.raises(ToolError, match=r"No occupancy plan for 2030-01-01.*2025-06-10"):
        forecast_demand(ctx, ForecastDemandInput(target_date=date(2030, 1, 1)))


def test_single_day_of_history_cannot_be_backtested(make_data_dir: DataDirFactory) -> None:
    meals = [["2025-01-03", "A", "Mina", "lunch", 1000, 1000, 800, 40.0]]
    context = ToolContext(data_dir=make_data_dir(meals=meals, plan=[["2025-01-04", "A", 1000]]))
    with pytest.raises(ToolError, match="Not enough history"):
        forecast_demand(context, ForecastDemandInput())


def test_service_level_bounds_are_validated() -> None:
    with pytest.raises(ValueError, match=r"less than or equal to 0\.999"):
        ForecastDemandInput(service_level=1.0)


@pytest.mark.parametrize(
    ("mape", "history", "expected"),
    [(2.0, 14, "high"), (2.0, 3, "medium"), (7.5, 14, "medium"), (12.0, 14, "low")],
)
def test_confidence_from(mape: float, history: int, expected: str) -> None:
    assert confidence_from(mape, history) == expected
