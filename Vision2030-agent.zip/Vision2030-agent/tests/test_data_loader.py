from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

from tests.conftest import MEAL_HEADER, TINY_MEALS, DataDirFactory
from zad.tools.context import ToolContext, ToolError
from zad.tools.data_loader import LoadServiceDataInput, ensure_loaded, load_service_data


def test_loads_sample_data(ctx: ToolContext) -> None:
    summary = load_service_data(ctx, LoadServiceDataInput())
    assert summary.records == 336 == len(ctx.records)
    assert len(summary.camps) == 8
    assert summary.sites == ["Makkah", "Mina"]
    assert (summary.first_date, summary.last_date, summary.days) == (
        date(2025, 5, 27),
        date(2025, 6, 9),
        14,
    )
    assert summary.total_meals_served <= summary.total_meals_prepared
    assert summary.charities == 5
    assert summary.planned_dates == [date(2025, 6, 10), date(2025, 6, 11)]
    assert "synthetic" in summary.provenance.lower()
    assert summary.provenance_ar


def test_totals_match_hand_computed_values(tiny_ctx: ToolContext) -> None:
    summary = load_service_data(tiny_ctx, LoadServiceDataInput())
    assert summary.total_meals_prepared == 4500
    assert summary.total_meals_served == 3750
    assert summary.total_plate_waste_kg == 147.0
    assert summary.provenance.startswith("unknown")
    assert summary.provenance_ar is None


def test_site_filter_is_case_insensitive_and_limits_plans(tiny_ctx: ToolContext) -> None:
    summary = load_service_data(tiny_ctx, LoadServiceDataInput(site="mina"))
    assert summary.camps == ["A"]
    assert {plan.camp_id for plan in tiny_ctx.plans} == {"A"}


def test_unknown_site_is_an_error(tiny_ctx: ToolContext) -> None:
    with pytest.raises(ToolError, match="No meal-service records for site 'Jeddah'"):
        load_service_data(tiny_ctx, LoadServiceDataInput(site="Jeddah"))


def test_missing_file_is_an_error(tmp_path: Path) -> None:
    with pytest.raises(ToolError, match="Data file not found"):
        load_service_data(ToolContext(data_dir=tmp_path), LoadServiceDataInput())


def test_invalid_row_reports_file_line_and_field(make_data_dir: DataDirFactory) -> None:
    bad = [*TINY_MEALS[:2], ["2025-01-03", "A", "Mina", "lunch", 1000, 900, 950, 1.0]]
    context = ToolContext(data_dir=make_data_dir(meals=bad))
    with pytest.raises(ToolError, match=r"meal_service\.csv line 4: .*cannot exceed"):
        load_service_data(context, LoadServiceDataInput())


def test_file_with_personal_data_column_is_rejected(make_data_dir: DataDirFactory) -> None:
    rows = [[*row, "SA"] for row in TINY_MEALS]
    context = ToolContext(
        data_dir=make_data_dir(meals=rows, meal_header=[*MEAL_HEADER, "nationality"])
    )
    with pytest.raises(ToolError, match="nationality: Extra inputs are not permitted"):
        load_service_data(context, LoadServiceDataInput())


def test_empty_file_is_an_error(make_data_dir: DataDirFactory) -> None:
    data_dir = make_data_dir()
    (data_dir / "charities.csv").write_text(
        "charity_id,name,daily_capacity_meals,distance_km,has_cold_chain\n", encoding="utf-8"
    )
    with pytest.raises(ToolError, match="no rows"):
        load_service_data(ToolContext(data_dir=data_dir), LoadServiceDataInput())


def test_malformed_manifest_is_an_error(make_data_dir: DataDirFactory) -> None:
    data_dir = make_data_dir()
    (data_dir / "manifest.json").write_text("{not json", encoding="utf-8")
    with pytest.raises(ToolError, match="not valid JSON"):
        load_service_data(ToolContext(data_dir=data_dir), LoadServiceDataInput())


def test_ensure_loaded_loads_once(tiny_ctx: ToolContext) -> None:
    first = ensure_loaded(tiny_ctx)
    assert ensure_loaded(tiny_ctx) is first
