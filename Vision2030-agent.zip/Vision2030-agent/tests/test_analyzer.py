from __future__ import annotations

import pytest

from zad.tools.analyzer import AnalyzeWasteInput, analyze_waste
from zad.tools.context import ToolContext


def test_overall_and_camp_metrics_match_hand_computation(tiny_ctx: ToolContext) -> None:
    result = analyze_waste(tiny_ctx, AnalyzeWasteInput(group_by="camp"))
    # overall: prepared 4500, served 3750 -> 750 unserved -> 16.67%; 147 kg / 3750 meals = 39.2 g
    assert result.overall.unserved_meals == 750
    assert result.overall.overprep_rate_pct == 16.67
    assert result.overall.plate_waste_g_per_served_meal == 39.2
    by_key = {group.key: group for group in result.groups}
    assert by_key["A"].overprep_rate_pct == 20.0
    assert by_key["A"].plate_waste_g_per_served_meal == 50.0
    assert by_key["B"].overprep_rate_pct == 10.0
    assert [group.key for group in result.groups] == ["A", "B"]  # worst first
    assert result.hotspots == ["A"]  # 20% is more than 2 points above 16.67%


@pytest.mark.parametrize(
    ("group_by", "expected_keys"),
    [
        ("site", {"Mina", "Makkah"}),
        ("meal_type", {"lunch"}),
        ("date", {"2025-01-01", "2025-01-02", "2025-01-03"}),
    ],
)
def test_group_by_dimensions(tiny_ctx: ToolContext, group_by: str, expected_keys: set[str]) -> None:
    result = analyze_waste(tiny_ctx, AnalyzeWasteInput(group_by=group_by))
    assert {group.key for group in result.groups} == expected_keys
    assert sum(group.meals_prepared for group in result.groups) == result.overall.meals_prepared


def test_always_names_at_least_one_hotspot(tiny_ctx: ToolContext) -> None:
    result = analyze_waste(tiny_ctx, AnalyzeWasteInput(group_by="meal_type"))
    assert result.hotspots == ["lunch"]


def test_sample_data_hotspots_are_the_camps_built_to_over_prepare(ctx: ToolContext) -> None:
    result = analyze_waste(ctx, AnalyzeWasteInput(group_by="camp"))
    assert result.hotspots[:2] == ["MINA-05", "MINA-02"]
    assert len(result.hotspots) <= 3
