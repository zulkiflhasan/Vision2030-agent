"""Live-path test: the real ``anthropic`` SDK against a local stub of the Messages API.

No network and no API key are involved. The stub replies with scripted messages in
the documented wire format, which checks that the agent's requests serialise through
the real SDK and that real SDK response objects are converted correctly.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Iterator
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

import anthropic
import pytest

from zad.agent import Agent
from zad.llm import AnthropicClient
from zad.tools.registry import TOOLS

SUMMARY = "Preparation can be reduced on 10 June while keeping the service level."


def message(content: list[dict[str, Any]], stop_reason: str) -> dict[str, Any]:
    return {
        "id": "msg_stub",
        "type": "message",
        "role": "assistant",
        "model": "claude-stub",
        "content": content,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": {"input_tokens": 1, "output_tokens": 1},
    }


def tool_use(call_id: str, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    return message(
        [{"type": "tool_use", "id": call_id, "name": name, "input": arguments}], "tool_use"
    )


SCRIPT = [
    message([{"type": "text", "text": '["Load the data", "Forecast", "Report"]'}], "end_turn"),
    tool_use("toolu_1", "load_service_data", {}),
    tool_use("toolu_2", "forecast_demand", {"service_level": 0.9}),
    tool_use("toolu_3", "generate_report", {"executive_summary": SUMMARY}),
    message([{"type": "text", "text": "The report is ready."}], "end_turn"),
]


class StubServer(HTTPServer):
    requests: list[dict[str, Any]]
    paths: list[str]


class StubHandler(BaseHTTPRequestHandler):
    server: StubServer

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        self.server.requests.append(json.loads(self.rfile.read(length)))
        self.server.paths.append(self.path)
        body = json.dumps(SCRIPT[len(self.server.requests) - 1]).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        """Silence the default request logging."""


@pytest.fixture
def stub(monkeypatch: pytest.MonkeyPatch) -> Iterator[StubServer]:
    for variable in (
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "ALL_PROXY",
        "http_proxy",
        "https_proxy",
        "all_proxy",
    ):
        monkeypatch.delenv(variable, raising=False)
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    server = StubServer(("127.0.0.1", 0), StubHandler)
    server.requests = []
    server.paths = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield server
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)


def test_agent_runs_through_the_real_sdk_against_a_stub_api(
    stub: StubServer, sample_dir: Path
) -> None:
    sdk = anthropic.Anthropic(
        api_key="test-key-not-real",
        base_url=f"http://127.0.0.1:{stub.server_port}",
        max_retries=0,
    )
    client = AnthropicClient(api_key=None, model="claude-stub", max_tokens=512, sdk_client=sdk)
    result = Agent(client, data_dir=sample_dir, mode="live", max_steps=6).run(
        "What should we prepare on 10 June?"
    )

    report = result.report
    assert report.mode == "live"
    assert report.plan == ["Load the data", "Forecast", "Report"]
    assert report.executive_summary == SUMMARY
    assert report.forecast.service_level == 0.9
    assert [(r.tool, r.ok) for r in report.trace] == [
        ("load_service_data", True),
        ("forecast_demand", True),
        ("generate_report", True),
    ]
    assert result.final_message == "The report is ready."
    assert result.model_calls == 5

    assert stub.paths == ["/v1/messages"] * 5
    planner, first, _, _, last = stub.requests
    assert "tools" not in planner
    assert planner["model"] == "claude-stub" and planner["max_tokens"] == 512
    assert [tool["name"] for tool in first["tools"]] == [spec.name for spec in TOOLS]
    assert "reply in English" in first["system"]
    assert [m["role"] for m in last["messages"]] == [
        "user", "assistant", "user", "assistant", "user", "assistant", "user",
    ]  # fmt: skip
    final_result = last["messages"][-1]["content"][0]
    assert final_result["type"] == "tool_result"
    assert final_result["tool_use_id"] == "toolu_3"
    assert json.loads(final_result["content"])["status"] == "report_ready"
