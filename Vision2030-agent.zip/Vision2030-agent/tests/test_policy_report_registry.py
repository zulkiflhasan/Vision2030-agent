from __future__ import annotations

import json

import pytest

from zad.i18n import LABELS
from zad.tools.context import ToolContext
from zad.tools.policy import GetPolicyContextInput, get_policy_context
from zad.tools.registry import TOOLS, anthropic_tool_schemas, execute_tool
from zad.tools.report import GenerateReportInput, generate_report, render_markdown

SUMMARY = "Preparation can be reduced while keeping the service level."


def test_policy_context_facts_are_sourced_and_bilingual(ctx: ToolContext) -> None:
    context = get_policy_context(ctx, GetPolicyContextInput())
    facts = {fact.fact_id: fact for fact in context.facts}
    assert set(facts) == {
        "flw_baseline",
        "flw_second_measurement",
        "hajj_1446_pilgrims",
        "sdg_12_3",
    }
    assert "33.1%" in facts["flw_baseline"].statement_en
    assert "33.1%" in facts["flw_baseline"].statement_ar
    assert "27.9%" in facts["flw_second_measurement"].statement_en
    assert "1,673,230" in facts["hajj_1446_pilgrims"].statement_en
    assert facts["hajj_1446_pilgrims"].source_url.startswith("https://www.stats.gov.sa/")
    assert all(fact.source_url.startswith("https://") for fact in context.facts)


def test_generate_report_runs_missing_steps_itself(ctx: ToolContext) -> None:
    report = generate_report(ctx, GenerateReportInput(executive_summary=SUMMARY))
    assert report.language == "en"
    assert report.mode == "mock"
    assert report.forecast.items
    assert report.redistribution.allocations
    assert len(report.recommendations) == 5
    assert len(report.context.facts) == 4


def test_executive_summary_must_be_substantive() -> None:
    with pytest.raises(ValueError, match="at least 20 characters"):
        GenerateReportInput(executive_summary="ok")


@pytest.mark.parametrize("language", ["en", "ar"])
def test_markdown_contains_every_section_and_tag(ctx: ToolContext, language: str) -> None:
    report = generate_report(ctx, GenerateReportInput(executive_summary=SUMMARY, language=language))
    markdown = render_markdown(report)
    labels = LABELS[language]
    for key in ("summary", "kpis", "redistribution", "recommendations", "context", "limitations"):
        assert f"## {labels[key]}" in markdown
    for item in report.recommendations:
        assert f"`SDG {item.sdg_target}`" in markdown
        assert item.confidence_note in markdown
    assert labels["inspector"] in markdown
    assert "https://doi.org/10.3390/su13169444" in markdown
    assert f"{report.forecast.total_recommended_prep:,}" in markdown


def test_arabic_and_english_reports_carry_identical_numbers(ctx: ToolContext) -> None:
    english = generate_report(ctx, GenerateReportInput(executive_summary=SUMMARY, language="en"))
    arabic = generate_report(ctx, GenerateReportInput(executive_summary=SUMMARY, language="ar"))
    assert english.forecast == arabic.forecast
    assert english.redistribution == arabic.redistribution
    assert [r.sdg_indicator for r in english.recommendations] == [
        r.sdg_indicator for r in arabic.recommendations
    ]


def test_tool_schemas_are_valid_for_the_messages_api() -> None:
    schemas = anthropic_tool_schemas()
    assert len(schemas) == len(TOOLS) >= 4
    assert len({schema["name"] for schema in schemas}) == len(schemas)
    for schema in schemas:
        assert set(schema) == {"name", "description", "input_schema"}
        assert schema["input_schema"]["type"] == "object"
        assert schema["input_schema"]["additionalProperties"] is False
        assert len(schema["description"]) > 40
        json.dumps(schema)  # must be JSON-serialisable


def test_execute_tool_success_records_trace(ctx: ToolContext) -> None:
    result = execute_tool(ctx, "load_service_data", {})
    assert result.ok
    assert json.loads(result.content)["records"] == 336
    assert [(t.step, t.tool, t.ok) for t in ctx.trace] == [(1, "load_service_data", True)]


def test_execute_tool_unknown_tool_is_reported_not_raised(ctx: ToolContext) -> None:
    result = execute_tool(ctx, "delete_everything", {})
    assert not result.ok
    assert "Unknown tool 'delete_everything'" in result.content
    assert "load_service_data" in result.content
    assert ctx.trace[-1].ok is False


def test_execute_tool_invalid_arguments_are_reported_not_raised(ctx: ToolContext) -> None:
    result = execute_tool(ctx, "analyze_waste", {"group_by": "nationality"})
    assert not result.ok
    assert result.content.startswith("Invalid arguments for analyze_waste: group_by:")
    extra = execute_tool(ctx, "forecast_demand", {"horizon": 3})
    assert "horizon: Extra inputs are not permitted" in extra.content


def test_execute_tool_tool_error_is_reported_not_raised(ctx: ToolContext) -> None:
    result = execute_tool(ctx, "forecast_demand", {"target_date": "2031-01-01"})
    assert not result.ok
    assert "No occupancy plan for 2031-01-01" in result.content


def test_report_tool_returns_compact_payload(ctx: ToolContext) -> None:
    result = execute_tool(ctx, "generate_report", {"executive_summary": SUMMARY})
    payload = json.loads(result.content)
    assert payload["status"] == "report_ready"
    assert [item["sdg_target"] for item in payload["recommendations"]] == [
        "12.3",
        "12.3",
        "2.1",
        "12.5",
        "11.6",
    ]
