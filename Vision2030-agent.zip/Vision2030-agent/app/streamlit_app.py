"""Optional Streamlit front end for Zad.

Run with:
    pip install -e ".[ui]"
    streamlit run app/streamlit_app.py
"""

from __future__ import annotations

import os

import streamlit as st

from zad.agent import AgentError
from zad.cli import run_agent
from zad.config import ConfigError
from zad.llm import LLMError
from zad.tools.report import render_markdown

EXAMPLES = {
    "English": "How many meals should we prepare tomorrow, and where should the surplus go?",
    "العربية": "كم وجبة نُعدّ غدًا وأين يذهب الفائض؟",
}

st.set_page_config(page_title="Zad — Vision 2030 food-waste agent", page_icon="🍽️")
st.title("Zad · زاد")
st.caption(
    "AI agent for reducing food waste in Hajj and Umrah catering — Saudi Vision 2030 · UN SDG 12.3"
)

has_key = bool(os.getenv("ANTHROPIC_API_KEY"))
example = st.radio("Example question", list(EXAMPLES), horizontal=True)
question = st.text_area("Question / السؤال", value=EXAMPLES[example], height=80)
mock = st.toggle(
    "Mock mode (offline, no API key)",
    value=not has_key,
    help="Uses the bundled synthetic data and canned model responses.",
)

if st.button("Run agent", type="primary"):
    try:
        with st.spinner("Running tools…"):
            result = run_agent(question, mock=mock)
    except (ConfigError, LLMError, AgentError) as exc:
        st.error(str(exc))
    else:
        report = result.report
        markdown = render_markdown(report)
        if report.language == "ar":
            st.markdown(f'<div dir="rtl">\n\n{markdown}\n\n</div>', unsafe_allow_html=True)
        else:
            st.markdown(markdown)
        st.info(result.final_message)
        st.download_button("Download report (Markdown)", markdown, file_name="zad_report.md")
        st.download_button(
            "Download report (JSON)", report.model_dump_json(indent=2), file_name="zad_report.json"
        )
