# Architecture

Zad is a small tool-using agent. The language model plans and decides which tool to
call next; **every number, SDG tag and confidence note is produced by deterministic
Python tools**, never by the model. That split is the main design decision: it makes
the output testable, identical in Arabic and English, and reproducible offline.

## Flow

```mermaid
flowchart TD
    U["User question<br/>(Arabic or English)"] --> L["Language detection<br/>i18n.detect_language"]
    L --> P["1 · Planner<br/>model call, no tools<br/>returns a JSON step list"]
    P --> A["2 · Tool-use loop<br/>agent.Agent._act"]

    subgraph LLM["LLMClient (same interface)"]
        direction LR
        LIVE["AnthropicClient<br/>Claude via anthropic SDK"]
        MOCK["MockClient<br/>scripted, offline, no key"]
    end
    A <-->|"messages + tool schemas<br/>tool_use / tool_result"| LLM

    subgraph TOOLS["Domain tools (tools/registry.py)"]
        direction TB
        T1["load_service_data<br/>validate CSV inputs"]
        T2["analyze_waste<br/>over-preparation, plate waste"]
        T3["forecast_demand<br/>forecast + preparation sizing + back-test"]
        T4["plan_redistribution<br/>surplus → charities"]
        T5["get_policy_context<br/>sourced national figures"]
        T6["recommend_actions<br/>SDG tag + confidence note"]
        T7["generate_report<br/>structured AgentReport"]
    end
    A -->|"execute_tool<br/>(validated arguments)"| TOOLS
    TOOLS -->|"JSON result or error"| A
    TOOLS <--> C[("ToolContext<br/>cached results + audit trace")]
    D[("data/sample/*.csv<br/>manifest.json")] --> T1
    R[("reference/national_context.json")] --> T5

    A --> G{"report built?"}
    G -- "no" --> F["Fallback: agent calls<br/>generate_report itself"]
    G -- "yes" --> O
    F --> O["3 · AgentReport (pydantic)<br/>→ Markdown / JSON"]
    O --> H["Human decision-maker<br/>approves or rejects each action"]
```

## Components

| Module | Responsibility |
|--------|----------------|
| `zad/agent.py` | The run cycle: plan, tool-use loop with a step limit, fallback report, error mapping. |
| `zad/llm.py` | `LLMClient` protocol, `AnthropicClient` (live) and `MockClient` (offline). |
| `zad/tools/registry.py` | Tool catalogue, JSON schemas for the Messages API, validated execution, audit trace. |
| `zad/tools/data_loader.py` | Reads and validates the three CSV inputs; rejects unknown columns. |
| `zad/tools/analyzer.py` | Over-preparation rate and plate waste by camp, site, meal or date; hotspots. |
| `zad/tools/forecaster.py` | Attendance-ratio forecast, service-level preparation sizing, walk-forward back-test. |
| `zad/tools/redistribution.py` | Greedy allocation of expected surplus to charities by distance and capacity. |
| `zad/tools/recommender.py` | Bilingual recommendation templates with SDG tags and confidence notes. |
| `zad/tools/policy.py` | Verified national figures with source URLs. |
| `zad/tools/report.py` | Builds `AgentReport` and renders Markdown. |
| `zad/models.py` | Pydantic models for inputs, tool outputs and the report. |
| `zad/i18n.py` | Language detection, labels, Arabic number agreement. |
| `zad/prompts/` | System and planner prompts as Markdown files. |
| `zad/cli.py` | Typer CLI (`zad run`, `zad tools`). |
| `app/streamlit_app.py` | Optional web UI over the same `run_agent` function. |

## Design decisions

1. **Numbers come from tools.** The model receives tool results and writes only the
   plan, the executive summary and a closing message. The system prompt forbids
   quoting figures that did not come from a tool, and the report tables are rendered
   directly from tool output, so a model error cannot change them.
2. **SDG tags are enforced by the type system.** `Recommendation.sdg_target`,
   `sdg_indicator` and `confidence_note` are required, pattern-checked fields. A
   recommendation without them cannot be constructed, and `AgentReport` requires at
   least one recommendation.
3. **One loop for live and mock.** `MockClient` implements the same `LLMClient`
   protocol and speaks the same wire format, so the end-to-end test exercises the real
   loop, real tool execution and real report building. Only the model is replaced.
4. **Errors go back to the model.** Unknown tools, invalid arguments and `ToolError`s
   are returned as `tool_result` blocks with `is_error`, so the model can correct its
   call. The loop has a step limit so a confused model cannot run forever.
5. **A report is guaranteed or the run fails loudly.** If the model skips
   `generate_report`, the agent builds the report itself from the cached results. If
   that is impossible, `AgentError` is raised with the underlying cause.
6. **Privacy by construction.** Input models forbid extra fields, so a file carrying
   personal-data columns is rejected instead of ingested.
7. **Confidence is computed, not asserted.** The forecast confidence comes from a
   walk-forward back-test (MAPE) and the length of history. Recommendations that
   depend on the forecast inherit it, one level lower where further assumptions are
   added.

## Forecast method

For each camp and meal:

- attendance ratio `r_t = meals_served / registered_pilgrims` for each past day;
- forecast ratio = exponentially weighted mean of `r_t` (alpha 0.5, newest heaviest);
- forecast meals = forecast ratio × planned headcount;
- preparation = `ceil(max(forecast + z·σ, forecast × 1.02))`, with σ the standard
  deviation of `r_t` scaled to meals and `z` the normal quantile of the service level;
- habitual preparation = mean of `meals_prepared / registered_pilgrims` × planned
  headcount, used as the comparison baseline.

The back-test re-forecasts each of the last three days from the days before it and
reports the mean absolute percentage error. Confidence is *high* below 5% with at
least 7 days of history, *medium* below 10%, otherwise *low*.

This is intentionally a simple, auditable baseline. See "Future work" in the README.
