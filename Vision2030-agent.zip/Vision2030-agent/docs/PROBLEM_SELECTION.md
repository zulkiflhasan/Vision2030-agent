# Phase 1 — Problem Selection

Author: Dr. Muhammad Zulkifl Hasan, University of Central Punjab (UCP), Lahore
Sources last checked: 13 November 2026

## 1. Vision 2030 context

Vision 2030 is organised around three themes: **A Vibrant Society**, **A Thriving
Economy** and **An Ambitious Nation** [S1]. The themes are delivered through Vision
Realization Programs (VRPs). Two of them matter for the problem chosen here:

- **Pilgrim Experience Program (PEP).** Its stated role is to give the largest possible
  number of Muslims the opportunity to perform Hajj and Umrah and to enrich their
  experience. One of its three key objectives is "Providing high-quality services for
  Hajj and Umrah pilgrims" [S2].
- **National Transformation Program (NTP).** Its published objectives include
  Objective 19, "Ensure development and food security", and Objective 16, "Reduce all
  types of pollution" [S3]. The National Program to Reduce Food Loss and Waste is run
  as part of the NTP [S4].

## 2. Shortlist and scoring

Each problem is scored from 1 (weak) to 5 (strong) on five criteria. The scores are the
author's judgement; the reasoning for each row is given below the table so that the
judgement can be challenged.

| # | Problem | Vision 2030 alignment | SDG impact | Open data | Feasible as one-repo agent | Measurable outcome | Total |
|---|---------|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | **Food loss and waste in Hajj/Umrah mass catering** | 5 | 5 | 3 | 5 | 5 | **23** |
| 2 | Water scarcity and the energy cost of desalination | 5 | 5 | 4 | 3 | 4 | 21 |
| 3 | Youth/female job–skill matching under Saudization (Nitaqat) | 5 | 4 | 4 | 4 | 3 | 20 |
| 4 | Urban heat and energy demand in Riyadh/Jeddah | 4 | 4 | 3 | 3 | 4 | 18 |
| 5 | Arabic/English patient triage and appointment load in primary care | 4 | 4 | 2 | 3 | 3 | 16 |

### Reasoning per problem

1. **Food loss and waste in Hajj/Umrah catering (23).** Two VRPs apply directly (PEP
   service quality, NTP food security). There is an official national baseline and a
   follow-up measurement, so progress is measurable against SDG target 12.3. Demand
   forecasting and surplus allocation are well-defined computations that fit a
   tool-using agent. The weak point is open data: national figures are published, but
   camp-level meal records are not, so the agent ships with synthetic sample data.
2. **Water and desalination (21).** Strong alignment (NTP Objective 20, "Ensure
   sustainable access to water resources" [S3]) and good national statistics: GASTAT's
   Water Accounts report that desalinated water made up 50% of distributed water in
   2023, up from 44% in 2022 [S8]. It scores lower on feasibility because useful
   recommendations need plant-level operating data and engineering models that cannot
   be validated inside one small repository.
3. **Job–skill matching under Nitaqat (20).** Strong alignment and regular GASTAT
   labour statistics; unemployment among Saudi women was 9.6% in Q2 2026 [S9]. It
   scores lower on measurable outcome because a matching agent's effect on employment
   cannot be observed without placement data, and it processes personal data, which
   raises the compliance burden.
4. **Urban heat and energy demand (18).** Relevant to quality of life and energy
   efficiency, but city-level load data is not openly available at useful resolution,
   and the result would be a forecasting model more than an agent.
5. **Primary-care triage (16).** High social value, but it depends on sensitive health
   data, has no open dataset, and clinical triage carries safety risks that a
   demonstration repository should not take on.

Road-safety incident analysis and SME licensing guidance were considered and left off
the shortlist: the first lacks open incident-level data, the second depends on
regulatory text that changes often and would need continual legal review.

## 3. Chosen problem

**Reducing food loss and waste in mass catering for pilgrims during Hajj and Umrah
peak seasons.**

### Verified facts

| Fact | Value | Source |
|------|-------|--------|
| National food loss and waste (FLW) baseline | 33.1% overall; 14.2% loss; 18.9% waste | [S4] |
| Second national FLW measurement (announced September 2025) | 27.9% overall; 12.1% loss; 15.8% waste | [S5] |
| Stated national commitment | Reduce FLW rates by 50% by 2030, in line with SDG 12.3 | [S4] |
| Pilgrims performing Hajj 1446 AH / 2025 | 1,673,230 (1,506,576 from abroad; 166,654 domestic) | [S6] |
| Surplus redistribution already practised | Charities in Makkah collect surplus food from Hajj camps and caterers | [S7] |

Notes on the figures:

- [S4] is the peer-reviewed publication of the national baseline study, written by the
  National Program team. It computes the rates from 2016 food statistics. [S5], a news
  report of the General Food Security Authority's announcement, calls the same
  baseline "2019" (the year the result was released) and gives the waste component as
  18.8% instead of 18.9%. Both are reported here as published; the difference does not
  affect anything the agent computes.
- No verified figure was found for the tonnage of food wasted specifically during
  Hajj, so none is quoted.

### Target users

- Catering supervisors and operations managers at pilgrim service companies and camps.
- Coordinators at food banks and food-preservation charities who collect surplus.
- Programme analysts tracking food-waste reduction for Vision 2030 and SDG reporting.

### Vision 2030 pillar, VRP and KPI served

| Level | Item |
|-------|------|
| Themes | A Vibrant Society (serving pilgrims) and An Ambitious Nation (protecting vital resources) [S1][S4] |
| VRP | Pilgrim Experience Program — "Providing high-quality services for Hajj and Umrah pilgrims" [S2] |
| VRP | National Transformation Program — Objective 19, "Ensure development and food security" [S3] |
| KPI | National food loss and waste index: 33.1% baseline, 27.9% at the second measurement [S4][S5] |

The PEP page does not publish a food-waste KPI, so the agent reports against the
national FLW index and against its own operational metrics (see `SDG_ALIGNMENT.md`).

### Problem statement

Catering for pilgrims is planned against registered headcounts, but actual attendance
at each meal varies with ritual movements, heat and group schedules. Operators
therefore over-prepare to avoid shortages, and the surplus is either discarded or
recovered late and informally. Saudi Arabia measures national food loss and waste at
27.9%, down from a 33.1% baseline, and has committed to halving it by 2030 [S4][S5].
The peak seasons concentrate very large numbers of meals into a few days and a few
square kilometres; Hajj 1446 AH alone hosted 1,673,230 pilgrims [S6]. A supervisor
needs three things each day: a defensible estimate of how many meals each camp will
actually serve, a preparation quantity that protects service quality without habitual
over-production, and a plan to move safe surplus to charities before it expires. This
repository builds an AI agent that produces those three outputs, in Arabic or English,
with every recommendation tied to an SDG target and a stated level of confidence.

## 4. Sources

- [S1] Vision 2030, Overview: https://vision2030.gov.sa/en/overview
- [S2] Vision 2030, Pilgrim Experience Program: https://www.vision2030.gov.sa/v2030/vrps/pep/
- [S3] Vision 2030, National Transformation Program: https://umbraco.vision2030.gov.sa/v2030/vrps/ntp
- [S4] Alshabanat, Z. et al. (2021). Quantifying Food Loss and Waste in Saudi Arabia.
  *Sustainability*, 13(16), 9444. https://doi.org/10.3390/su13169444
- [S5] Argaam, citing the Saudi Press Agency (30 September 2025), "Saudi food waste
  index down 16%": https://www.argaam.com/en/article/articledetail/id/1846487
- [S6] General Authority for Statistics (GASTAT), Hajj Statistics Publication 2025:
  https://www.stats.gov.sa/documents/d/guest/hajj-statistics-publication-2025en-1-pdf
- [S7] Arab News (28 May 2026), "Hajj service providers step up efforts to reduce food
  waste and redistribute surplus meals": https://www.arabnews.com/node/2645216/saudi-arabia
- [S8] Saudi Gazette (5 January 2025), reporting GASTAT's Water Accounts 2023:
  https://saudigazette.com.sa/article/648375
- [S9] Arab News, reporting GASTAT's Labour Market Statistics Q2 2026:
  https://www.arabnews.pk/business/saudi-arabia-unemployment-falls-to-3-as-labor-market-expands-3002761

[S5], [S7], [S8] and [S9] are news reports of official releases, used because the
primary bulletins could not be retrieved directly. They are marked as such so a reader
can replace them with the primary documents.
