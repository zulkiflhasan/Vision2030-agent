# Phase 2 — SDG Alignment

Target and indicator wording below is taken from the UN Statistics Division's SDG
indicator metadata [U1–U5]. Nothing here is paraphrased into a new indicator.

## 1. Primary and secondary SDGs

### Primary — SDG 12, Responsible Consumption and Production

- **Target 12.3:** "By 2030, halve per capita global food waste at the retail and
  consumer levels and reduce food losses along production and supply chains, including
  post-harvest losses."
- **Indicator 12.3.1:** "(a) Food loss index and (b) food waste index." Part (b) covers
  food waste at retail and consumer level, which includes food service [U1][U2].
- **Why primary:** the agent's main job is to cut over-preparation in food service,
  which is food waste in the sense of indicator 12.3.1(b).

### Secondary

| SDG target | Indicator | Why it applies |
|------------|-----------|----------------|
| **2.1** — "By 2030, end hunger and ensure access by all people, in particular the poor and people in vulnerable situations, including infants, to safe, nutritious and sufficient food all year round" | **2.1.2** — "Prevalence of moderate or severe food insecurity in the population, based on the Food Insecurity Experience Scale (FIES)" [U3] | Safe surplus meals are routed to food banks that serve people in need. |
| **12.5** — "By 2030, substantially reduce waste generation through prevention, reduction, recycling and reuse" | **12.5.1** — "National recycling rate, tons of material recycled" [U4] | Plate waste that cannot be eaten is directed to composting. The 12.5.1 metadata counts composting and anaerobic digestion as recycling [U4]. |
| **11.6** — "By 2030, reduce the adverse per capita environmental impact of cities, including by paying special attention to air quality and municipal and other waste management" | **11.6.1** — "Proportion of municipal solid waste collected and managed in controlled facilities out of total municipal waste generated, by cities" [U5] | Less food entering the municipal waste stream of Makkah and the holy sites during peak load. |

**What the agent does and does not measure.** The official indicators are national or
city statistics compiled by custodian agencies. The agent does not compute them. It
produces operational metrics (meals not over-prepared, meals redistributed, kilograms
diverted) that *contribute to* those indicators. Each recommendation is tagged with
the target and indicator it contributes to, and the report says this explicitly.

## 2. Capability map

| Agent capability (tool) | Vision 2030 objective | SDG target / indicator | Measurable metric produced by the agent |
|---|---|---|---|
| Load and validate meal-service records (`load_service_data`) | NTP Obj. 19 — Ensure development and food security | 12.3 / 12.3.1(b) | Records loaded, camps and days covered, rows rejected by validation |
| Waste hotspot analysis (`analyze_waste`) | NTP Obj. 19; NTP Obj. 16 — Reduce all types of pollution | 12.3 / 12.3.1(b) | Over-preparation rate (%) and plate waste (g per served meal) by camp, site, meal and date |
| Demand forecast and preparation sizing (`forecast_demand`) | PEP — Providing high-quality services for Hajj and Umrah pilgrims | 12.3 / 12.3.1(b) | Forecast meals, recommended preparation, meals avoided versus habitual preparation, back-test error (MAPE %) |
| Surplus redistribution plan (`plan_redistribution`) | NTP Obj. 19; NTP Obj. 3 — Enable non-profit organizations to achieve greater impact | 2.1 / 2.1.2 | Meals allocated to charities, meals left unallocated, share of surplus placed (%) |
| Composting of inedible plate waste (`recommend_actions`) | NTP Obj. 16 — Reduce all types of pollution | 12.5 / 12.5.1 and 11.6 / 11.6.1 | Plate waste (kg) identified for diversion from landfill |
| National context with citations (`get_policy_context`) | Vision 2030 reporting | 12.3 / 12.3.1 | National FLW index values shown next to operational metrics |
| Bilingual structured report (`generate_report`) | PEP — service quality for pilgrims of all languages | All of the above | One report per run; every recommendation carries an SDG tag and a confidence note |

Objective wording is from the Vision 2030 programme pages [V1][V2].

## 3. Risks and ethics

### Data privacy — Saudi Personal Data Protection Law (PDPL)

- The agent is designed to work on **aggregate operational data only**: counts of
  registered pilgrims, meals prepared, meals served and kilograms of waste per camp.
  It does not need names, passport or permit numbers, nationalities, health or dietary
  records of individuals. The data models forbid extra fields, so a file that carries
  such columns is rejected at load time instead of being silently ingested.
- A real deployment must still be assessed under the PDPL and its implementing
  regulations, which are issued by the Saudi Data and AI Authority (SDAIA) and include
  a separate regulation on transferring personal data outside the Kingdom [P1]. Points
  to settle before using real data: whether camp-level counts could identify small
  groups, where the data is stored and processed, and whether sending prompts to a
  model hosted outside the Kingdom counts as a cross-border transfer. In live mode
  this agent sends tool results (aggregates) to the Anthropic API; operators who
  cannot allow that should run the tools without the language model (`--mock`).
- The sample data in this repository is synthetic and contains no personal data.

### Bias

- **Between camps.** A forecast trained on a camp with volatile attendance will
  recommend a larger buffer; a camp with little history gets a low-confidence
  forecast. The agent reports confidence per forecast so that small or new camps are
  not silently treated as well-understood.
- **Service shortfall.** Reducing preparation shifts risk onto pilgrims if the
  forecast is wrong. The sizing rule is therefore one-sided: it adds a buffer for a
  chosen service level and never recommends preparing fewer meals than the forecast.
- **Proxy discrimination.** The data model has no nationality, language, gender or
  package-tier field. Preparation and redistribution cannot vary by them.
- **Charity allocation.** Allocation is by distance and declared capacity, which can
  favour large, central charities. The plan lists unallocated surplus and the rule
  used, so a coordinator can override it.

### Arabic-language fairness

- Arabic and English are both first-class: the question language is detected, and
  report labels, recommendations and confidence notes exist in both languages as
  fixed templates, not as machine translation at run time.
- Numbers are computed by tools, not by the language model, so they are identical in
  both languages.
- Known limitation: the Arabic templates are Modern Standard Arabic. They have not
  been reviewed by a native-speaking domain expert, and dialect input is not tested.
  The Arabic wording of Vision 2030 objectives in reports is the author's rendering of
  the English programme pages, not the official Arabic text.

### Human in the loop

Every recommendation carries a `requires_human_approval` flag. The agent is a
decision-support tool: it proposes, a named person decides.

### What the agent must never decide alone

1. **Food safety.** Whether a surplus meal is safe to redistribute is decided by a
   qualified food-safety inspector under the applicable food-safety regulations. The
   agent only proposes candidates.
2. **Cutting preparation below forecast demand.** It may never recommend preparing
   fewer meals than it expects to be eaten.
3. **Special diets and medical meals.** Meals for pilgrims with medical or dietary
   requirements are outside the sizing rule.
4. **Contracts, penalties and payments.** It does not judge caterer performance for
   contractual purposes.
5. **Choice of beneficiaries.** It allocates to registered charities by capacity; it
   does not decide who receives food.
6. **Official reporting.** Its metrics are operational estimates and must not be
   submitted as official SDG indicator values.

## 4. Sources

- [U1] UNSD metadata, indicator 12.3.1(a): https://unstats.un.org/sdgs/metadata/files/Metadata-12-03-01A.pdf
- [U2] UNSD metadata, indicator 12.3.1(b): https://unstats.un.org/sdgs/metadata/files/Metadata-12-03-01B.pdf
- [U3] UNSD metadata, indicator 2.1.2: https://unstats.un.org/sdgs/metadata/files/Metadata-02-01-02.pdf
- [U4] UNSD metadata, indicator 12.5.1: https://unstats.un.org/sdgs/metadata/files/Metadata-12-05-01.pdf
- [U5] UNSD metadata, indicator 11.6.1: https://mdgs.un.org/sdgs/metadata/files/Metadata-11-06-01.docx
- [V1] Vision 2030, Pilgrim Experience Program: https://www.vision2030.gov.sa/v2030/vrps/pep/
- [V2] Vision 2030, National Transformation Program: https://umbraco.vision2030.gov.sa/v2030/vrps/ntp
- [P1] Clyde & Co (8 September 2023), "Saudi Arabia issues Implementing Regulations to
  the Personal Data Protection Law" (secondary legal commentary):
  https://www.clydeco.com/en/insights/2023/09/saudi-arabia-issues-implementing-regulations
